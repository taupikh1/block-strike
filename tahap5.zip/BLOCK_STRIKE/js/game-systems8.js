/* Tahap 8: shared weapon presentation, bot loadouts and input lifecycle. */
const heldModels={},heldLoads={};
const BOT_POOLS={CT:['m4a1','aug','mp5','usp','awp','famas','p90'],T:['ak47','galil','mac10','glock18','scout','elite','mp5']};
function loadHeld(id){
 if(heldModels[id])return Promise.resolve(heldModels[id]);
 return heldLoads[id]||(heldLoads[id]=new Promise((ok,no)=>new THREE.GLTFLoader().load('assets/models/held/'+id+'.glb',g=>{heldModels[id]=g;ok(g)},undefined,no)));
}
function equipBot(b,i){
 const id=BOT_POOLS[b.team][i%BOT_POOLS[b.team].length],w=W[id];
 Object.assign(b,{weaponId:id,weaponModel:null,damage:w.dmg*.38,fireRate:w.rate,effectiveRange:w.slot==='pistol'?32:Math.max(38,70-w.sp*800),accuracy:Math.max(.35,.62-w.sp*5),sound:w.sound,ammo:w.mag,burst:0});
 loadHeld(id).then(g=>{
  if(!b.g.parent||b.dead||!b.body)return;
  b.weaponModel=[];
  g.scene.traverse(o=>{if(!o.isMesh)return;
   const boneName=(o.userData.attachBone||'').replace(/\s/g,'_');
   const bone=b.body.getObjectByName(boneName);if(!bone){console.warn('Missing weapon attachment bone',boneName);return}
   const mesh=o.clone();mesh.frustumCulled=false;bone.add(mesh);b.weaponModel.push(mesh);
  });
 }).catch(e=>console.warn('Held model failed',id,e));
}
function disposeBot(b){
 if(b.mixer){b.mixer.stopAllAction();b.mixer.uncacheRoot(b.body)}
 b.parts.forEach(p=>{p.geometry.dispose();p.material.dispose()});
 b.g.traverse(o=>{if(o.isSkinnedMesh)o.skeleton.dispose()});S.remove(b.g);
}
function resetInputs(){
 fh=fl=jmp=firedLatch=false;jx=jy=0;Object.keys(K).forEach(k=>K[k]=0);
 jid=lid=null;jb.style.display=jk.style.display='none';
}
function requestLock(){try{const p=$('pad').requestPointerLock?.();p?.catch?.(()=>{})}catch(e){}}
function inputBlocked(){return !running||!$('buyMenu').classList.contains('hidden')||!$('menu').classList.contains('hidden')}
function syncAim(){
 const sniper=aiming&&['awp','scout','g3sg1','sg550'].includes(cur());
 $('scopeOverlay').classList.toggle('hidden',!sniper);$('scopeOverlay').classList.toggle('active',sniper);
 $('scopeOverlay').setAttribute('aria-hidden',String(!sniper));
 $('cross').classList.toggle('hidden',sniper);$('ads').classList.toggle('active',aiming);
 document.body.classList.toggle('has-scope',!!scopeLevels(cur()));if(vm)vm.visible=!sniper;
 if(!aiming&&cam){cam.fov=baseFov;cam.updateProjectionMatrix()}
}
let shotgunReload=null;
function clipDuration(name,fallback){const a=vm?.userData.weaponAnimation?.actions[name];return a?a.getClip().duration:fallback}
function shotgunPhase(phase){
 const names={start:'start_reload',insert:'insert',end:'after_reload'};
 const state=vm?.userData.weaponAnimation;
 let name=names[phase];if(phase==='insert'&&!state?.actions[name])name='reload';
 const duration=clipDuration(name,phase==='insert'?.55:.3);
 shotgunReload.phase=phase;shotgunReload.time=Math.max(.1,duration);
 if(state){state.queue=[];state.currentKind='idle';playWeaponClip(state,name,false)}
 if(phase==='insert')playOriginalSound('m3_insertshell.wav',.25);
}
function updateReload(dt){
 if(shotgunReload){
  shotgunReload.time-=dt;
  if(shotgunReload.time<=0){const st=A[cur()];
   if(shotgunReload.phase==='insert'){st.mag++;st.res--;hud()}
   if(shotgunReload.phase==='end'){shotgunReload=null;reloading=0;playWeaponAnimation('idle');hud();return}
   shotgunPhase(st.mag<W[cur()].mag&&st.res>0?'insert':'end');
  }
  reloading=.1;return;
 }
 if(reloading>0){reloading-=dt;if(reloading<=0){reloading=0;const st=A[cur()],n=Math.min(W[cur()].mag-st.mag,st.res);st.mag+=n;st.res-=n;hud()}}
}
function pauseToMenu(){activeVoices.forEach(s=>{try{s.stop()}catch(e){}});running=false;reloadSfxToken++;resetInputs();aiming=false;syncAim();$('buyMenu').classList.add('hidden');$('menu').classList.remove('hidden');document.body.classList.remove('playing');if(document.pointerLockElement)document.exitPointerLock()}
addEventListener('blur',resetInputs);
document.addEventListener('visibilitychange',()=>{if(document.hidden)resetInputs()});
document.addEventListener('pointerlockchange',()=>{if(!document.pointerLockElement)resetInputs()});

function disposeFallback(g){if(g&&!g.userData.weaponAnimation)g.traverse(o=>{o.geometry?.dispose();[].concat(o.material||[]).forEach(m=>m.dispose())})}

function placeMapSpawns(){
 if(activeMapData?.id==='es_kvartal'){LayoutNav.snap(P.pos);bots.forEach(b=>LayoutNav.snap(b.g.position));return}
 if(!window.bspCol)return;
 const graph=window.NavGraph?.graph();
 const list=team=>{
  if(graph)return graph.spawns.filter(s=>s.team===team).map(s=>V(...s.pos));
  const anchor=activeMapData.spawn[team==='CT'?'ct':'t'];
  return bspCol.spawns.map(h=>V(...BSP.toGame(bspCol.T,h))).sort((a,b)=>Math.hypot(a.x-anchor[0],a.z-anchor[2])-Math.hypot(b.x-anchor[0],b.z-anchor[2]));
 };
 const ct=list('CT'),t=list('T'),counts={CT:playerTeam==='CT'?1:0,T:playerTeam==='T'?1:0};
 const own=playerTeam==='CT'?ct:t;if(own.length)P.pos.copy(own[0]);
 bots.forEach(b=>{const spawns=b.team==='CT'?ct:t;if(spawns.length)b.g.position.copy(spawns[counts[b.team]++%spawns.length]);b.nav=null});
}
