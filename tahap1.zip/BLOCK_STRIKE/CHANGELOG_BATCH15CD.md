# BLOCK STRIKE — Batch 15C + 15D

Baseline: `BLOCK_STRIKE_BATCH15B_GRENADE_FX_FULL_PAKET_1–3_DARI_3.zip`.

## 15C: Weapon modes / sniper scopes

- New `js/weapon-modes15c.js` deterministic tick-based burst scheduler. Glock 18 toggles semi/burst; FAMAS toggles full-auto/burst. Burst performs three separate recoil, ammo, projectile raycasts, model animations, and hit resolution, with a bounded interval/recovery and no auto-burst on sustained trigger in burst mode.
- Fixed old FAMAS behavior that spent 3 rounds and applied 3 hits in a single frame. Dedicated GoldSrc burst audio runs once per burst; source assets `famas-burst.wav` and `glock18-2.wav` already shipped in baseline.
- Burst cancels on weapon switch, pause, match reset, blocked input or empty magazine. Supports 1–2 round partial bursts and reload after an emptied 3-round burst.
- Mobile alternate-action button shows the active fire mode and accessibility label; V/right click remain supported.
- AWP/Scout scope is lowered after firing; level cycling and reload behavior use existing zoom and HUD, with wheel scoped adjustment no longer scrolling the page.

## 15D: CT/T bot AI

- New `js/bot-tactics15d.js`: distance-based engage, low-HP retreat, same-team separation, short obstacle recovery and bounded strafe.
- Bot hit probability now reflects bot movement instead of `WASD`/touch input on the human player.
- Non-BSP map navigation uses the existing `LayoutNav` walkable grid for routing around obstacles during pursuit of known objectives and radio orders, rather than direct collision-prone movement only.
- BSP `NavGraph` A* fixes: far waypoint no longer forces a new path search every frame; repath on elapsed cache age, moved goal, or confirmed stall; never assume coordinate 0 is an uninitialized previous position; missing paths are cached briefly.
- Preserves sight checks, team-vs-team logic, named bots, money, radio commands, difficulty settings, grenades, shield, spectator and buy menu.

## Scope / status

- No new maps or online mode; no dependencies added.
- No new binary CS assets. Licensing limitations documented in `ASSET_NOTICES.md` still apply.
- Verification details and limitations in `QA_BATCH15CD.md`.
