# QA: Batch 15C + 15D

Date: 2026-11-18. Baseline: Batch 15B (includes 15A Tactical Shield and 15E Spectator).

## Passed

- `node tools/qa/batch15cd_unit.cjs`: 15/15. Verifies three discrete timed rounds, short magazines, cancellation, no duplicate bursts, bounded background-tab updates, team spacing, hold orders, low-HP retreat, stuck recovery and finite movement.
- `python tools/qa/batch15cd_browser.py`: 52/52 Chromium integration checks at 844×390 touch/landscape and 1280×720 desktop. Real Three.js scene math and DOM with simulated WebGL renderer/model loading: Glock semi/burst, FAMAS auto/burst, dedicated burst audio once per action, switch cancellation, low-ammo burst, AWP/Scout two zoom levels, shooting/reloading scope reset, 8- and 32-player matches, CT/T counts, AI updates, secondary touch control and zero uncaught JavaScript errors.
- `python tools/qa/run15cd_regressions.py`: 12/12 existing suites; menu 48/48, create-match rules 10/10, shield inventory 33/33, hold-fire/touch 34/34, spectator simulated browser 78/78, spectator module 4/4, native shield assets 27/27, shield runtime 25/25, grenade effects 48/48, grenade base 44/44, grenade real models 18/18, asset validation passed. Details in `qa/batch15cd/*.json`.
- All edited/new JavaScript syntax validated with Node 22; all release ZIPs require CRC verification before acceptance.

## Limitations

- Chromium uses a **simulated** WebGL renderer and mock model/texture loading; this does not validate real GPU shader output, Safari iPhone 13 physical touch/rendering, auditory fidelity, or a human full-match playthrough.
- Alternate map BSP graph code is corrected but the currently distributed game only offers Dust Block; navigation on non-shipped `cs_kvartal` is not gameplay-certified.
- AI recovery is a bounded heuristic and will not solve every possible complex collision/navmesh edge case. Large matches (25–32) remain performance-dependent on device.
- Sound timing relies on original WAV files already shipped; rights to publicly redistribute third-party assets are not established by these tests.

## Files

- `qa/batch15cd/unit-results.json`
- `qa/batch15cd/browser-results.json`
- `qa/batch15cd/regression-results.json`
