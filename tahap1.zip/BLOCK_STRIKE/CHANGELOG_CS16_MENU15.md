# BLOCK STRIKE CS 1.6 Menu 15 — Change Log

Date: 2026-11-18

- Simplified in-game main menu to **BLOCK STRIKE / Classic Edition** with original-source-inspired CS 1.6 navigation and preserved existing background.
- New functional Create Game PC-style Server, Game, CPU Player tabs. Only Dust Block is offered because new maps are not yet compatible. Configured Phase10 bots/difficulty, round length, buy time and starting money; input settings persist between matches.
- New Options PC-style Multiplayer, Keyboard, Mouse, Audio, Video, Voice, Touch tabs; real connected settings, explicit offline voice/servers limitations, crosshair and HUD sizing, nickname, mobile controls, sound, and classic character model selection.
- Fixed Settings and New Game Cancel to restore previous user settings and prevent accidental config persistence.
- Preserved original 14A–G shield/grenade/multitouch logic and the CS16 Extra character/audio packages.
- No map changes, cheat integration, GoldSrc DLL execution, or patching of queued Batch 15A–15D bugs. The incomplete, separate 15E spectator work is not bundled.
- Source model and resource coverage is now documented in AUDIT_CS16_MODELS_MENU15.md.
