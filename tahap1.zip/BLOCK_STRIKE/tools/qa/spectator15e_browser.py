#!/usr/bin/env python3
"""Batch 15E smoke in Chromium SwiftShader; never claims real iPhone GPU certification."""
import json,sys,time,re
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
out=root/'qa'/'spectator15e';out.mkdir(parents=True,exist_ok=True)
checks=[];errors=[];http=[]
def check(label,actual,expected=True):
 ok=(actual==expected);checks.append({'name':label,'passed':ok,'got':actual,'expected':expected})
 if not ok:print('FAIL',label,actual,'expected',expected)
 return ok
# Serve the unchanged game HTML with scripts and CSS inlined for sandboxed Chromium.
# The asset loader is stubbed in this browser QA only; production files are unmodified.
html=(root/'index.html').read_text()
for src in re.findall(r'<link rel="stylesheet" href="([^"]+)">',html):
 html=html.replace(f'<link rel="stylesheet" href="{src}">','<style>'+(root/src).read_text()+'</style>')
mock_fetch='<script>window.fetch=async function(url){return String(url).includes("dust_block.json")?new Response('+json.dumps(json.dumps(json.loads((root/'assets/maps/dust_block.json').read_text())))+',{status:200}):new Response("",{status:404})}</script>'
html=html.replace('<script src="js/vendor/three.min.js"></script>','<script>'+(root/'js/vendor/three.min.js').read_text()+'</script>'+mock_fetch)
for src in ['js/vendor/GLTFLoader.js','js/vendor/SkeletonUtils.js']:
 html=html.replace(f'<script src="{src}"></script>','<script>'+(root/src).read_text()+'</script>')
mock_models='''<script>
THREE.GLTFLoader.prototype.load=function(path,onLoad){const group=new THREE.Group(),bone=new THREE.Group();bone.name='Bip01_R_Hand';group.add(bone);queueMicrotask(()=>onLoad({scene:group,animations:[]}));return {}};
THREE.TextureLoader.prototype.load=function(path){return new THREE.Texture()};
// Simulated WebGL renderer, because this runner cannot create a real GL context.
// Scene/camera/math/animation logic remain real Three.js objects.
THREE.WebGLRenderer=class {constructor(options){this.domElement=options.canvas;this.shadowMap={enabled:false};this.info={render:{frame:0}};this.autoClear=true}setPixelRatio(){}setSize(){}render(){this.info.render.frame++}clearDepth(){}dispose(){}};
</script>'''
html=html.replace('<script src="js/bsp-render.js"></script>',mock_models+'<script src="js/bsp-render.js"></script>')
for src in re.findall(r'<script src="([^"]+)"></script>',html):
 html=html.replace(f'<script src="{src}"></script>','<script>\n'+(root/src).read_text()+'\n</script>')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--disable-gpu-sandbox','--disable-dev-shm-usage'])
 for label,viewport,touch in [('mobile-landscape',{'width':844,'height':390},True),('desktop',{'width':1280,'height':720},False)]:
  page=browser.new_page(viewport=viewport,device_scale_factor=1,has_touch=touch,is_mobile=touch);page.set_default_timeout(7000)
  page.on('pageerror',lambda e:errors.append(str(e.stack or e)))
  page.on('response',lambda r:http.append(f'{r.status()} {r.url}') if r.status()>=400 else None)
  page.goto('about:blank');page.set_content(html,wait_until='load')
  page.wait_for_timeout(300)
  check(label+' module exposed',page.evaluate('typeof Spectator15E'), 'object')
  page.evaluate("() => { const q=document.getElementById('q');q.value='0';q.dispatchEvent(new Event('change',{bubbles:true})) }")
  try:
   page.evaluate('beginMatch()')
   page.wait_for_function('running && bots.length>0 && !!R && vm',timeout=30000)
   page.wait_for_timeout(500)
   state=page.evaluate('({running,bots:bots.length,weapon:cur(),team:playerTeam,playerHp:P.hp})')
   print(label,'started',state)
   check(label+' playable match',state['running'] and state['bots']>0)
   page.evaluate('() => {P.hp=0;Phase13.onDeath()}')
   page.wait_for_timeout(150)
   check(label+' enters spectating',page.evaluate('Phase13.getDebugState().spectating'))
   check(label+' same-team target',page.evaluate('bots.find(b=>b.botId===Phase13.getDebugState().observed)?.team===playerTeam'))
   check(label+' first-person mode',page.evaluate('Phase13.getDebugState().specMode'),'first')
   check(label+' HUD visible',page.locator('#spectatorHud').is_visible())
   page.screenshot(path=str(out/(label+'-first-person.png')))
   for mode in ['locked','chase','free','map','chase-map','first']:
    page.locator('#specMode').select_option(mode)
    page.wait_for_timeout(150)
    check(label+' '+mode+' mode',page.evaluate('Phase13.getDebugState().specMode'),mode)
    check(label+' '+mode+' camera finite',page.evaluate('Number.isFinite(cam.position.x)&&Number.isFinite(cam.position.y)&&Number.isFinite(cam.position.z)'))
    check(label+' '+mode+' hidden bot correct',page.evaluate('Phase13.getObserved().g.visible'),mode!='first')
    check(label+' '+mode+' viewmodel layer correct',page.evaluate('Phase13.shouldRenderSpecWeapon()'),mode=='first')
    if mode=='chase-map':page.screenshot(path=str(out/(label+'-chase-overview.png')))
   # Navigation never reveals enemies, and manual selection disables director.
   page.locator('#specNext').click()
   check(label+' manual director off',page.evaluate('Phase13.getDebugState().autoDirector'),False)
   check(label+' target remains teammate',page.evaluate('Phase13.getObserved().team===playerTeam'))
   page.locator('#specAuto').click()
   check(label+' director toggle on',page.evaluate('Phase13.getDebugState().autoDirector'))
   # Make action unmistakably on another teammate (bots still update in game).
   page.evaluate('() => {for(const b of bots){b.visibleEnemy=null;b.lastShot=null} const team=bots.filter(b=>!b.dead&&b.team===playerTeam);if(team.length>1){const candidate=team.find(b=>b!==Phase13.getObserved());const opponent=bots.find(x=>x.team!==playerTeam&&!x.dead);if(opponent)candidate.visibleEnemy={id:"qa",pos:opponent.g.position,bot:opponent,isP:false};candidate.lastShot={at:performance.now()}}Phase13.updateSpectator(4)}')
   check(label+' director stays on own side',page.evaluate('Phase13.getObserved()?.team===playerTeam'))
   # Free roam on mobile: a pressed directional button should translate the camera.
   page.locator('#specMode').select_option('free')
   before=page.evaluate('cam.position.toArray()')
   if touch:
    bounds=page.locator('[data-spec-move="forward"]').bounding_box()
    page.mouse.move(bounds['x']+bounds['width']/2,bounds['y']+bounds['height']/2)
    page.mouse.down()
    page.wait_for_timeout(170)
    page.mouse.up()
   else:
    page.keyboard.down('w');page.wait_for_timeout(170);page.keyboard.up('w')
   after=page.evaluate('cam.position.toArray()')
   check(label+' free look movement',sum((a-b)**2 for a,b in zip(before,after))>.0001)
   # End round and verify cameras/bot meshes reset.
   page.evaluate('() => {Phase13.beforeRound()}')
   check(label+' spec ends after round',page.evaluate('Phase13.getDebugState().spectating'),False)
   check(label+' observed mesh restored',page.evaluate('bots.every(b=>b.g.visible!==false)'))
   check(label+' spec HUD hidden after respawn',not page.locator('#spectatorHud').is_visible())
  except Exception as e:
   errors.append(label+': '+str(e));print('BROWSER FATAL',label,repr(e))
   page.screenshot(path=str(out/(label+'-error.png')))
  finally:page.close()
 browser.close()
check('no uncaught JavaScript errors',len(errors),0)
check('no HTTP errors',len(http),0)
report={'checks':checks,'errors':errors,'http_errors':http,'passed':sum(c['passed'] for c in checks),'total':len(checks),'browser':'Chromium simulated WebGL renderer, real Three.js scene/camera and bot logic','date':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
(out/'QA_RESULTS.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'total':report['total'],'errors':errors[:8],'http':http[:8]},indent=2))
if report['passed']!=report['total']:sys.exit(1)
