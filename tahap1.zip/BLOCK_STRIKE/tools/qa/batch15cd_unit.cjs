'use strict';
const {readFileSync,writeFileSync,mkdirSync}=require('fs');
const {join,resolve}=require('path');
const vm=require('vm');
const assert=require('node:assert/strict');
const ROOT=resolve(__dirname,'../..'),report=[];
function check(name,fn){try{fn();report.push({name,pass:true});console.log('PASS',name)}catch(e){report.push({name,pass:false,error:String(e.stack||e)});console.error('FAIL',name,e)}}
const c=vm.createContext({Math,console});
for(const script of ['js/weapon-modes15c.js','js/bot-tactics15d.js'])vm.runInContext(readFileSync(join(ROOT,script),'utf8'),c,{filename:script});
const f=vm.runInContext('WeaponModes15C',c),ai=vm.runInContext('BotTactics15D',c);
check('15C modes only Glock/FAMAS',()=>{assert.equal(f.configured('glock18'),true);assert.equal(f.configured('famas'),true);assert.equal(f.configured('awp'),false)});
check('15C burst schedules three discrete shots across frames',()=>{
 f.cancel();let ammo=20,seen=[];assert.equal(f.start('glock18',ammo),true);ammo--;
 assert.equal(ammo,19);assert.equal(f.tick(.08,'glock18',true,()=>{ammo--;seen.push(ammo);return true}),0);
 assert.equal(ammo,19);assert.equal(f.tick(.02,'glock18',true,()=>{ammo--;seen.push(ammo);return true}),1);
 assert.equal(f.tick(.1,'glock18',true,()=>{ammo--;seen.push(ammo);return true}),1);
 assert.deepEqual(seen,[18,17]);assert.equal(f.active(),false)
});
check('15C FAMAS two-round short magazine never overdraws',()=>{
 f.cancel();let ammo=2;assert.equal(f.start('famas',ammo),true);ammo--;let seen=0;
 f.tick(.095,'famas',true,()=>{ammo--;seen++;return true});
 assert.equal(seen,1);assert.equal(ammo,0);assert.equal(f.active(),false)
});
check('15C single remaining round never starts a burst',()=>{f.cancel();assert.equal(f.start('glock18',1),false);assert.equal(f.active(),false)});
check('15C switching weapons cancels pending rounds',()=>{f.cancel();f.start('famas',25);let shots=0;f.tick(.3,'awp',true,()=>{shots++;return true});assert.equal(shots,0);assert.equal(f.active(),false)});
check('15C reloading or round transition cancels queued shots',()=>{f.cancel();f.start('glock18',20);f.tick(.2,'glock18',false,()=>{throw Error('unexpected')});assert.equal(f.active(),false)});
check('15C tick is bounded after tab suspension',()=>{f.cancel();f.start('famas',25);let shots=0;f.tick(200,'famas',true,()=>{shots++;return true});assert.equal(shots,2);assert.equal(f.active(),false)});
check('15C no duplicate burst request while active',()=>{f.cancel();assert.equal(f.start('glock18',20),true);assert.equal(f.start('glock18',20),false);f.cancel()});
const bot=(x,z,team='CT',hp=100)=>({g:{position:{x,y:0,z}},team,hp,strafe:1});
check('15D far target advances and strafe offsets',()=>{const b=bot(0,0),d=ai.engage(b,{x:0,z:-30},{});assert.ok(d.z<0);assert.ok(d.x>0)});
check('15D close threat retreats, wounded bot retreats earlier',()=>{const b=bot(0,0,'CT',100),low=bot(0,0,'CT',15);assert.ok(ai.engage(b,{x:0,z:-5},{}).z>0);assert.ok(ai.engage(low,{x:0,z:-14},{}).z>0)});
check('15D hold-order stays still while retaining fire line',()=>{const b=bot(0,0);b.radioOrder={mode:'hold'};assert.equal(ai.engage(b,{x:15,z:0},{}).x,0);assert.equal(ai.engage(b,{x:15,z:0},{}).z,0)});
check('15D teammates separate but enemies do not cause teammate repulsion',()=>{const b=bot(0,0),ally=bot(.6,0),foe=bot(-.6,0,'T');const a=ai.separate(b,[b,ally,foe]);assert.ok(a.x<0);assert.equal(ai.separate(b,[b,foe]).x,0)});
check('15D bot recovery triggers only after being stationary',()=>{const b=bot(0,0);for(let i=0;i<4;i++)assert.equal(ai.recover(b,true,0,3,.1),false);assert.equal(ai.recover(b,true,.1,3,.1),false);let triggered=false;for(let i=0;i<10;i++)triggered=ai.recover(b,true,0,3,.1)||triggered;assert.equal(triggered,true);assert.ok(b.recoveryTime>0);assert.equal(b.strafe,-1);assert.equal(b.nav,null)});
check('15D recovery side-step finite and reset when idle',()=>{const b=bot(0,0);b.recoveryTime=.5;const x=ai.sidestep(b,1,0);assert.ok(Number.isFinite(x.x)&&Number.isFinite(x.z)&&x.z>0);ai.recover(b,false,0,3,.1);assert.equal(b.recoveryTime,0)});
check('15D no separation from same-position allies',()=>{const b=bot(0,0),other=bot(0,0);const s=ai.separate(b,[b,other]);assert.ok(Number.isFinite(s.x+s.z))});
const out=join(ROOT,'qa/batch15cd/unit-results.json');mkdirSync(join(ROOT,'qa/batch15cd'),{recursive:true});
writeFileSync(out,JSON.stringify({passed:report.filter(x=>x.pass).length,total:report.length,checks:report},null,2));
console.log('RESULT',report.filter(x=>x.pass).length,'/',report.length);
if(report.some(x=>!x.pass))process.exitCode=1;
