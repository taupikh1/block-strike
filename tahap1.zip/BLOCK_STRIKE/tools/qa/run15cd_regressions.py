from pathlib import Path
import subprocess,json,sys
r=Path(__file__).resolve().parents[2]
tests=['cs16_menu15.py','cs16_menu15_match.py','tahap14c.py','tahap14efg.py','spectator15e_browser.py','spectator15e.test.cjs','batch15a_native_assets.py','batch15a_runtime.py','batch15b_effects.py','tahap14d.py','tahap14d_real_models.py','validate_assets.py']
report=[]
for t in tests:
 file=r/'tools/qa'/t;cmd=['node' if t.endswith('.cjs') else 'python',str(file)]
 print('RUN',t,flush=True)
 try:
  a=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=105)
  tail='\n'.join((a.stdout+a.stderr).splitlines()[-7:]);passed=a.returncode==0
  print(('PASS' if passed else 'FAIL'),t,tail[-450:],flush=True)
  report.append(dict(test=t,passed=passed,exit=a.returncode,output_tail=tail))
 except subprocess.TimeoutExpired:
  print('TIMEOUT',t,flush=True);report.append(dict(test=t,passed=False,error='timeout'))
(r/'qa/batch15cd').mkdir(parents=True,exist_ok=True)
(r/'qa/batch15cd/regression-results.json').write_text(json.dumps({'passed':sum(x['passed'] for x in report),'total':len(report),'results':report},indent=2))
print('SUMMARY',sum(x['passed'] for x in report),'/',len(report),flush=True)
sys.exit(0 if all(x['passed'] for x in report) else 1)
