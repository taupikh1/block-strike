#!/usr/bin/env python3
"""Batch 15C/15D browser integration in real Chromium DOM and Three.js scene graph,
with simulated renderer + GLTF loading (not GPU/WebGL validation)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,re,sys,traceback
ROOT=Path(__file__).resolve().parents[2]
REPORT=ROOT/'qa/batch15cd/browser-results.json'
checks=[];errors=[]
def ck(label,value):
 ok=bool(value);checks.append({'name':label,'pass':ok});print(('PASS' if ok else 'FAIL'),label,flush=True)
html=(ROOT/'index.html').read_text()
for src in re.findall(r'<link rel="stylesheet" href="([^"]+)">',html):
 html=html.replace(f'<link rel="stylesheet" href="{src}">','<style>\n'+(ROOT/src).read_text()+'\n</style>')
mock_fetch='<script>window.fetch=async function(url){return String(url).includes("dust_block.json")?new Response('+json.dumps(json.dumps(json.loads((ROOT/'assets/maps/dust_block.json').read_text())))+',{status:200}):new Response("",{status:404})};</script>'
html=html.replace('<script src="js/vendor/three.min.js"></script>', '<script>\n'+(ROOT/'js/vendor/three.min.js').read_text()+'\n</script>'+mock_fetch)
for src in ['js/vendor/GLTFLoader.js','js/vendor/SkeletonUtils.js']:
 html=html.replace(f'<script src="{src}"></script>','<script>\n'+(ROOT/src).read_text()+'\n</script>')
mock='''<script>
THREE.WebGLRenderer=class{constructor(o){this.domElement=o.canvas;this.shadowMap={enabled:false};this.info={render:{frame:0}};}setPixelRatio(){}setSize(){}render(){this.info.render.frame++}clearDepth(){}dispose(){}};
THREE.GLTFLoader.prototype.load=function(path,onLoad){const g=new THREE.Group(),bone=new THREE.Group();bone.name='Bip01_R_Hand';g.add(bone);queueMicrotask(()=>onLoad({scene:g,animations:[new THREE.AnimationClip('idle',.3,[]),new THREE.AnimationClip('shoot',.15,[]),new THREE.AnimationClip('draw',.1,[])]}));return {}};
THREE.TextureLoader.prototype.load=function(){return new THREE.Texture()};
</script>'''
html=html.replace('<script src="js/bsp-render.js"></script>',mock+'<script src="js/bsp-render.js"></script>')
for src in re.findall(r'<script src="([^"]+)"></script>',html):
 html=html.replace(f'<script src="{src}"></script>','<script>\n'+(ROOT/src).read_text()+'\n</script>')
assert '<script src=' not in html
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu','--disable-web-security','--disable-dev-shm-usage'])
 for label,viewport,mobile in [('iphone13-landscape',{'width':844,'height':390},True),('desktop',{'width':1280,'height':720},False)]:
  page=browser.new_page(viewport=viewport,is_mobile=mobile,has_touch=mobile)
  local_errors=[];page.on('pageerror',lambda e:local_errors.append(str(e)))
  try:
   page.goto('about:blank');page.set_content(html,wait_until='load');page.wait_for_timeout(100)
   ck(label+' helper modules loaded',page.evaluate('typeof WeaponModes15C==="object"&&typeof BotTactics15D==="object"'))
   page.evaluate('Phase10.setConfig({players:8,difficulty:"normal"},false)')
   page.evaluate('beginMatch()')
   page.wait_for_function('running && bots.length>=7 && !!R && !!vm',timeout=20000)
   page.evaluate('bots.forEach(b=>{b.cd=999;b.accuracy=0});P.hp=10000')
   ck(label+' game boot preserved',page.evaluate('running && bots.length===7 && !inputBlocked()'))
   # Direct integration tests run in the browser task, without animation-frame interleaving.
   result=page.evaluate('''() => {
    const res={},ready=(id,mag=20)=>{WeaponModes15C.cancel();inventory=[id,'knife'];setW(0);swapT=0;cool=0;reloading=0;A[id].mag=mag;A[id].res=90;fh=fl=false;firedLatch=false;return id};
    ready('glock18');if(Phase9.glockBurst)Phase9.secondaryAction();
    const glockSemi=!Phase9.glockBurst;let before=A.glock18.mag;shoot();res.glockSemiSingle=A.glock18.mag===before-1&&!WeaponModes15C.active();
    cool=0;Phase9.secondaryAction();before=A.glock18.mag;shoot();const initial=A.glock18.mag;
    const g2=WeaponModes15C.tick(.11,'glock18',true,()=>shoot('slash',true)===true);
    const g3=WeaponModes15C.tick(.11,'glock18',true,()=>shoot('slash',true)===true);
    res.glockBurstThree=Phase9.glockBurst&&initial===before-1&&g2===1&&g3===1&&A.glock18.mag===before-3&&!WeaponModes15C.active();
    ready('glock18',2);cool=0;shoot();const b2=WeaponModes15C.tick(.11,'glock18',true,()=>shoot('slash',true)===true);res.shortMagazine=A.glock18.mag===0&&b2===1&&!WeaponModes15C.active();
    ready('glock18',20);cool=0;shoot();res.cancelOnSwitch=WeaponModes15C.active();setW(1);res.cancelOnSwitch=res.cancelOnSwitch&&!WeaponModes15C.active()&&cur()==='knife';
    ready('famas',25);if(!Phase9.famasBurst)Phase9.secondaryAction();before=A.famas.mag;shoot();
    const f1=WeaponModes15C.tick(.095,'famas',true,()=>shoot('slash',true)===true);
    const f2=WeaponModes15C.tick(.095,'famas',true,()=>shoot('slash',true)===true);
    res.famasBurstDiscrete=Phase9.famasBurst&&A.famas.mag===before-3&&f1===1&&f2===1;
    Phase9.secondaryAction();cool=0;before=A.famas.mag;shoot();res.famasAutoMode=!Phase9.famasBurst&&A.famas.mag===before-1&&!WeaponModes15C.active();
    // Verify one original burst recording per trigger, not three overlapping long WAVs.
    const originalSound=playOriginalSound,emitted=[];
    playOriginalSound=(file,...args)=>{emitted.push(file)};
    ready('famas',25);Phase9.secondaryAction();shoot();WeaponModes15C.tick(.095,'famas',true,()=>shoot('slash',true)===true);WeaponModes15C.tick(.095,'famas',true,()=>shoot('slash',true)===true);
    res.famasAudioOnce=emitted.filter(x=>x==='famas-burst.wav').length===1;
    ready('glock18',20);if(!Phase9.glockBurst)Phase9.secondaryAction();shoot();WeaponModes15C.tick(.11,'glock18',true,()=>shoot('slash',true)===true);WeaponModes15C.tick(.11,'glock18',true,()=>shoot('slash',true)===true);
    res.glockAudioOnce=emitted.filter(x=>x==='glock18-2.wav').length===1;
    playOriginalSound=originalSound;
    ready('awp',10);toggleAim();syncAim();res.scopeFirst=aiming&&zoomIdx===0&&scopeZoom('awp')===24&&$('scopeOverlay').classList.contains('active');
    toggleAim();res.scopeSecond=aiming&&zoomIdx===1&&scopeZoom('awp')===10;
    toggleAim();res.scopeOff=!aiming&&zoomIdx===0;
    toggleAim();cool=0;before=A.awp.mag;shoot();res.scopeShotReset=!aiming&&A.awp.mag===before-1&&!$('scopeOverlay').classList.contains('active');
    ready('scout',10);toggleAim();toggleAim();res.scoutTwoLevels=scopeZoom('scout')===15;
    ready('awp',4);toggleAim();reload();res.reloadUnscope=!aiming&&zoomIdx===0;
    res.aiHas7Bots=bots.length===7;const b=bots[0];const old=b.g.position.clone();
    const order=Phase10.goal(b);res.aiGoalFinite=Number.isFinite(order.pos.x)&&Number.isFinite(order.pos.z);
    for(let i=0;i<5;i++)botUpdate(b,.12);
    res.aiUpdateFinite=Number.isFinite(b.g.position.x)&&Number.isFinite(b.g.position.z)&&Number.isFinite(b.g.rotation.y);
    res.layoutNavAvailable=typeof LayoutNav.step==='function'&&typeof LayoutNav.reset==='function';
    res.noAccidentalReload=!WeaponModes15C.active();
    return res;
   }''')
   for name,value in result.items():ck(label+' '+name,value)
   # Touch input includes alternate fire on the right-hand ADS control.
   touch=page.evaluate('''() => {inventory=['glock18','knife'];setW(0);swapT=0;reloading=0;const old=Phase9.glockBurst;
    const e=new PointerEvent('pointerdown',{bubbles:true,cancelable:true,pointerId:89,pointerType:'touch',button:0});$('ads').dispatchEvent(e);
    const u=new PointerEvent('pointerup',{bubbles:true,cancelable:true,pointerId:89,pointerType:'touch',button:0});$('ads').dispatchEvent(u);
    return Phase9.glockBurst!==old&&$('ads').getAttribute('aria-label')==='FIRE MODE'}''')
   ck(label+' mobile alternate-fire button connected',touch)
   large=page.evaluate('''() => {Phase10.setConfig({players:32,difficulty:'hard'},false);startRound();
    const teams={CT:bots.filter(b=>b.team==='CT').length,T:bots.filter(b=>b.team==='T').length};
    bots.forEach(b=>{b.cd=999});for(const b of bots)botUpdate(b,.12);
    return {count:bots.length===31,teams:teams.CT===15&&teams.T===16,
      finite:bots.every(b=>Number.isFinite(b.g.position.x)&&Number.isFinite(b.g.position.z)&&Number.isFinite(b.g.rotation.y))};}''')
   for name,value in large.items():ck(label+' 32-player '+name,value)
   ck(label+' no runtime page errors',not local_errors)
  except Exception as exc:
   ck(label+' browser completed',False)
   local_errors.append('Browser: '+str(exc)+' '+traceback.format_exc())
  finally:
   errors+=local_errors;page.close()
 browser.close()
REPORT.parent.mkdir(parents=True,exist_ok=True)
REPORT.write_text(json.dumps({'passed':sum(c['pass'] for c in checks),'total':len(checks),'checks':checks,'errors':errors,'environment':'Chromium actual DOM, real Three.js math and objects, simulated WebGL and model decoding; not real iPhone physical GPU.'},ensure_ascii=False,indent=2))
print('RESULT',sum(c['pass'] for c in checks),'/',len(checks))
for error in errors[:4]:print('ERR',error[:800])
sys.exit(0 if all(c['pass'] for c in checks) and not errors else 1)
