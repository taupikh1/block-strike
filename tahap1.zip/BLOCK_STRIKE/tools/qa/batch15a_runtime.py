#!/usr/bin/env python3
"""Batch 15A browser CPU+DOM integration using genuine shield GLBs, simulated renderer only."""
import base64, json, re, sys
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2];out=root/'qa/batch15a';out.mkdir(exist_ok=True)
assets=['shield_usp','shield_glock18','shield_p228','shield_deagle','shield_fiveseven',
        'shield_knife','shield_hegrenade','shield_flashbang','shield_smokegrenade']
raw={a:base64.b64encode((root/f'assets/models/weapons/{a}.glb').read_bytes()).decode() for a in assets}
html=(root/'index.html').read_text()
for path in re.findall(r'<link rel="stylesheet" href="([^"]+)">',html):
 html=html.replace(f'<link rel="stylesheet" href="{path}">','<style>'+(root/path).read_text()+'</style>')
map_json=json.dumps(json.loads((root/'assets/maps/dust_block.json').read_text()))
mock='<script>const __nativeFetch=window.fetch.bind(window);window.fetch=async u=>String(u).includes("dust_block.json")?new Response('+json.dumps(map_json)+',{status:200}):String(u).startsWith("blob:")?__nativeFetch(u):new Response("",{status:404});</script>'
html=html.replace('<script src="js/vendor/three.min.js"></script>','<script>'+(root/'js/vendor/three.min.js').read_text()+'</script>'+mock)
for path in ['js/vendor/GLTFLoader.js','js/vendor/SkeletonUtils.js']:
 html=html.replace(f'<script src="{path}"></script>','<script>'+(root/path).read_text()+'</script>')
models='''<script>
window.__gltfFiles=__ASSETS__;
window.__requestedGlbs=[];
THREE.GLTFLoader.prototype.load=function(url,onLoad,progress,onError){
 const name=String(url).split('/').pop().split('.')[0];window.__requestedGlbs.push(name);
 if(window.__gltfFiles[name]){
  try{const bytes=Uint8Array.from(atob(window.__gltfFiles[name]),s=>s.charCodeAt(0));
   this.parse(bytes.buffer,'',onLoad,onError)}catch(e){onError?.(e)}return {};
 }
 const group=new THREE.Group(),bone=new THREE.Group();bone.name='Bip01_R_Hand';group.add(bone);
 queueMicrotask(()=>onLoad({scene:group,animations:[]}));return {};
};

THREE.WebGLRenderer=class{constructor(o){this.domElement=o.canvas;this.shadowMap={enabled:false};this.info={render:{frame:1}};this.autoClear=true}setPixelRatio(){}setSize(){}render(){this.info.render.frame++}clearDepth(){}clear(){}dispose(){}};
</script>'''.replace('__ASSETS__',json.dumps(raw,separators=(',',':')))
html=html.replace('<script src="js/bsp-render.js"></script>',models+'<script src="js/bsp-render.js"></script>')
for path in re.findall(r'<script src="([^"]+)"></script>',html):
 html=html.replace(f'<script src="{path}"></script>','<script>\n'+(root/path).read_text()+'\n</script>')
assert '<script src=' not in html
results=[];errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':844,'height':390},has_touch=True,is_mobile=True)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('console',lambda m:print('CONSOLE',m.type,m.text[:240]) if m.type in ('error','warning') else None)
 page.goto('about:blank');page.set_content(html,wait_until='load')
 def check(name,js):
  try:
   value=page.evaluate(js);passed=bool(value)
   results.append({'name':name,'pass':passed,'value':str(value)[:140]})
   if not passed:print('FAIL',name,repr(value),flush=True)
  except Exception as e:
   results.append({'name':name,'pass':False,'error':str(e)[:220]});print('ERROR',name,str(e)[:200],flush=True)
 def wait(expr):
  try: page.wait_for_function(expr,timeout=10000)
  except Exception:
   print('DEBUG WAIT',expr,'ERRORS',errors[:8]);print('STATE',page.evaluate("({asset:weaponAssetName('shield'),inv:inventory,cur:cur(),vm:vm?.userData,loaded:Object.keys(weaponModels),requested:window.__requestedGlbs.slice(-12),loads:Object.keys(weaponModelLoads),running,view:!!viewScene})"));raise
 page.locator('#go').click();page.locator('#continueMatchConfig').click();page.locator('[data-team="CT"]').click();page.locator('#startMatch').click()
 wait('running && !!vm && !!R')
 check('match starts on 15E baseline','running && typeof Spectator15E==="object"')
 check('hidden bot collision proxies never write white or depth',"bots.some(b=>b.parts?.length>0&&b.parts.every(p=>p.material?.depthWrite===false&&p.material?.colorWrite===false))")
 check('empty character placeholder gear does not render',"bots.filter(b=>b.body).every(b=>b.gearMeshes.length===0)")
 page.evaluate('money=16000;buyTime=100;purchase("shield")')
 wait("vm?.userData.nativeShield15a==='shield_usp'")
 check('USP shield loads one native rig',"vm.userData.nativeShield15a==='shield_usp' && vm.children.length===2 && !!vm.userData.weaponAnimation && Phase14B.inspect(vm)===null")
 check('USP shield all GoldSrc animations present',"['idle1','shoot1','reload','draw','shield_up','shield_down'].every(n=>vm.userData.weaponAnimation.actions[n])")
 check('shield positioned behind camera',"vm.children[0].position.z===-.48")
 check('shield raised blocks fire',"(()=>{cool=swapT=reloading=0;const old=A.usp.mag;Phase9.secondaryAction();shoot();return Phase9.shieldRaised&&A.usp.mag===old&&vm.userData.weaponAnimation.activeName==='shield_up'})()")
 check('shield lowered permits pistol fire',"(()=>{cool=swapT=reloading=0;Phase9.secondaryAction();const old=A.usp.mag;shoot();return !Phase9.shieldRaised&&A.usp.mag===old-1})()")
 for pistol in ['deagle','p228','glock18','fiveseven']:
  page.evaluate('() => {money=16000;buyTime=100;purchase('+json.dumps(pistol)+')}')
  wait('vm?.userData.nativeShield15a===' + json.dumps('shield_'+pistol))
  check(pistol+' shield selects native combined model',"vm.userData.nativeShield15a==="+json.dumps('shield_'+pistol)+"&&vm.children.length===2&&vm.children[0].position.z===-.48")
  check(pistol+' single actual viewmodel after switch',"viewScene.children.filter(x=>x.userData?.nativeShield15a).length===1&&Phase14B.inspect(vm)===null")
  check(pistol+' ammo and shield inventory preserved',"inventory.includes('shield')&&Phase9.shieldPistol()==="+json.dumps(pistol)+"&&A[Phase9.shieldPistol()].mag>0")
 page.evaluate("setW(inventory.indexOf('knife'))")
 wait("vm?.userData.nativeShield15a==='shield_knife'")
 check('knife paired with shield native asset',"cur()==='knife'&&vm.userData.nativeShield15a==='shield_knife'")
 check('knife slash and stab use native clips',"(()=>{playWeaponAnimation('attack');const a=vm.userData.weaponAnimation.activeName;playWeaponAnimation('stab');return a==='slash'&&vm.userData.weaponAnimation.activeName==='hit'})()")
 page.evaluate("setW(inventory.indexOf('shield'))")
 wait("vm?.userData.nativeShield15a==='shield_fiveseven'")
 check('switching away and back restores matching shield',"vm.userData.nativeShield15a==='shield_fiveseven'&&cur()==='shield'")
 page.evaluate("() => {grenades.he=1;selectedGrenade='he';Phase9.throwGrenade()}")
 wait("!!weaponModels.shield_hegrenade")
 check('HE grenade picks native shield+grenade model',"window.__requestedGlbs.includes('shield_hegrenade')&&!!weaponModels.shield_hegrenade")
 check('non-flash weapon switching never sets white flash overlay',"getComputedStyle(document.getElementById('flashEffect')).opacity==='0'&&Phase9.getDebugState().flashTimer===0")
 report={'environment':'Chromium: real GLTFLoader for 9 shield GLBs, renderer mocked. NOT real WebGL/Safari visual certification.',
  'passed':sum(x['pass'] for x in results),'total':len(results),'failed':[x for x in results if not x['pass']],'pageErrors':errors,'checks':results}
 (out/'runtime-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
 print('BATCH15A RUNTIME',report['passed'],'/',report['total'],'PAGE ERRORS',len(errors),flush=True)
 if errors:print('ERRORS',errors[:5])
 browser.close()
 sys.exit(1 if report['failed'] or errors else 0)
