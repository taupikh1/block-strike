#!/usr/bin/env python3
"""Batch 15B: sourced sprite integrity + Chromium Three scene integration.
Real Three.Sprite/Texture/GLTF browser logic; renderer mocked (not GPU QA).
"""
import base64,json,re,sys,struct
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2];out=root/'qa/batch15b';out.mkdir(parents=True,exist_ok=True)
assets=root/'assets/cs16-grenade-fx'
manifest=json.loads((assets/'manifest.json').read_text())
counts={'he-flame':3,'he-dust':10,'flash-core':1,'smoke':12}
checks=[];errors=[]
def check(name,ok,detail=''):
 ok=bool(ok);checks.append({'name':name,'pass':ok,'detail':str(detail)[:220]});print('PASS' if ok else 'FAIL',name,str(detail)[:80],flush=True)
for kind,count in counts.items():
 files=sorted(assets.glob(kind+'-*.png'))
 check(kind+' frame count',len(files)==count,len(files))
 check(kind+' all source-derived frames nonempty',all(Image.open(x).getbbox() is not None for x in files))
 check(kind+' mapping to Drive source sprite',manifest[kind]['source_zip']=='cs16_files-02.zip' and len(manifest[kind]['selected_source_frames'])==count)
check('flash radial alpha avoids opaque white quad',Image.open(assets/'flash-core-00.png').getpixel((0,0))[3]==0 and Image.open(assets/'flash-core-00.png').getpixel((32,32))[3]>180)
check('sustained smoke uses substantial GoldSrc source frame',sum(p>32 for p in Image.open(assets/'smoke-08.png').getchannel('A').getdata())>1000)
images={x.name:base64.b64encode(x.read_bytes()).decode() for x in assets.glob('*.png')}
html=(root/'index.html').read_text()
for path in re.findall(r'<link rel="stylesheet" href="([^"]+)">',html):
 html=html.replace(f'<link rel="stylesheet" href="{path}">','<style>'+(root/path).read_text()+'</style>')
map_json=json.dumps(json.loads((root/'assets/maps/dust_block.json').read_text()))
mock='<script>const __nativeFetch=window.fetch.bind(window);window.fetch=async u=>String(u).includes("dust_block.json")?new Response('+json.dumps(map_json)+',{status:200}):String(u).startsWith("blob:")?__nativeFetch(u):new Response("",{status:404});</script>'
html=html.replace('<script src="js/vendor/three.min.js"></script>','<script>'+(root/'js/vendor/three.min.js').read_text()+'</script>'+mock)
for path in ['js/vendor/GLTFLoader.js','js/vendor/SkeletonUtils.js']:
 html=html.replace(f'<script src="{path}"></script>','<script>'+(root/path).read_text()+'</script>')
shim='''<script>
window.__fxImg=__IMAGES__;window.__loadedFx=[];
THREE.TextureLoader.prototype.load=function(url,onLoad,progress,onError){
 const tex=new THREE.Texture(),name=String(url).split('/').pop(),b64=window.__fxImg[name];
 if(!b64){if(onError)queueMicrotask(()=>onError(new Error('no asset')));return tex;}
 const image=new Image();image.onload=()=>{tex.image=image;tex.needsUpdate=true;window.__loadedFx.push(name);onLoad?.(tex)};
 image.onerror=e=>onError?.(new Error('image decode '+name));
 image.src='data:image/png;base64,'+b64;return tex;
};
THREE.GLTFLoader.prototype.load=function(url,onLoad,progress,onError){
 const group=new THREE.Group(),bone=new THREE.Group();bone.name='Bip01_R_Hand';group.add(bone);
 queueMicrotask(()=>onLoad({scene:group,animations:[]}));return {};
};
THREE.WebGLRenderer=class{constructor(o){this.domElement=o.canvas;this.shadowMap={enabled:false};this.info={render:{frame:1}};this.autoClear=true}setPixelRatio(){}setSize(){}render(){this.info.render.frame++}clearDepth(){}clear(){}dispose(){}};
</script>'''.replace('__IMAGES__',json.dumps(images,separators=(',',':')))
html=html.replace('<script src="js/bsp-render.js"></script>',shim+'<script src="js/bsp-render.js"></script>')
for path in re.findall(r'<script src="([^"]+)"></script>',html):
 html=html.replace(f'<script src="{path}"></script>','<script>\n'+(root/path).read_text()+'\n</script>')
assert '<script src=' not in html
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':844,'height':390},has_touch=True,is_mobile=True)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('about:blank');page.set_content(html,wait_until='load')
 def js(name,expr):
  try:result=page.evaluate(expr);check(name,result)
  except Exception as e:check(name,False,str(e)[:130])
 page.wait_for_function('window.__loadedFx?.length>=26',timeout=15000)
 js('all 26 PNG effect textures decode in Chromium','window.__loadedFx.length===26')
 js('module initialized before Phase9','typeof GrenadeFX15B=== "object" && typeof Phase9==="object"')
 page.locator('#go').click();page.locator('#continueMatchConfig').click();page.locator('[data-team="CT"]').click();page.locator('#startMatch').click()
 page.wait_for_function('running && !!vm && !!R',timeout=15000)
 js('baseline retains spectator and shield mods','typeof Spectator15E==="object" && typeof Phase14B==="object"')
 for kind,count in counts.items():
  js(kind+' texture pool has '+str(count),'GrenadeFX15B.debug().textureCounts['+json.dumps(kind)+']==='+str(count))
 for kind in ['he','flash','smoke']:
  page.evaluate('() => {Phase9.resetRound();P.hp=100;grenades.he=grenades.flash=grenades.smoke=0;grenades['+json.dumps(kind)+']=1;selectedGrenade='+json.dumps(kind)+';}')
  js(kind+' can begin player throw','Phase9.throwGrenade()===true')
  js(kind+' duplicate throw blocked','Phase9.throwGrenade()===false')
  page.evaluate('''() => {for(let i=0;i<180;i++) {Phase9.update(.05);
   const s=Phase9.getDebugState();if((s.fx.burstCount>0 || s.smoke>0) && s.projectiles===0)break;}}''')
  if kind!='smoke':
   js(kind+' triggers world-space animated burst','Phase9.getDebugState().fx.burstTypes.includes('+json.dumps(kind)+')')
   js(kind+' effect is made of actual Three sprites','S.children.some(x=>x.isSprite && x.material.transparent && x.material.depthWrite===false)')
   js(kind+' core/dust uses fully decoded source textures','S.children.filter(x=>x.isSprite).some(x=>x.material.map?.image?.width>0)')
   page.evaluate('() => {for(let i=0;i<22;i++)Phase9.update(.05)}')
   js(kind+' burst disposes after animation','Phase9.getDebugState().fx.burstCount===0')
   js(kind+' does not leave world flash sprites','S.children.filter(x=>x.isSprite).length===0')
  else:
   js('smoke persists after projectile is gone','Phase9.getDebugState().smoke===1 && Phase9.getDebugState().projectiles===0')
   js('smoke has 20 actual source-backed sprites','S.children.some(g=>g.children.length===20 && g.children.every(c=>c.isSprite))')
   page.evaluate('() => {for(let i=0;i<65;i++)Phase9.update(.05)}')
   js('smoke expands to gameplay LOS radius','Phase9.getDebugState().smokeRadii[0]>Grenade14D.TYPES.smoke.radius-0.2')
   js('smoke visibly opaque after growth','S.children.filter(x=>x.children.length===20).some(g=>g.children.some(c=>c.material.opacity>.32 && c.material.map?.image?.width===72))')
   page.evaluate('() => {for(let i=0;i<330;i++)Phase9.update(.05)}')
   js('smoke 17.5s timer clears sprites','Phase9.getDebugState().smoke===0 && !S.children.some(g=>g.children.length===20)')
  js(kind+' grenade ammo consumed once','grenades['+json.dumps(kind)+']===0')
 js('round reset releases pending burst and flash overlay','(()=>{GrenadeFX15B.init(S);GrenadeFX15B.burst("he",new THREE.Vector3(0,1,0));Phase9.resetRound();const s=Phase9.getDebugState();return s.fx.burstCount===0&&s.smoke===0&&s.flashStrength===0})()')
 js('no sprite resources are hidden in shield model','Phase9.getDebugState().fx.spriteCount===0')
 browser.close()
check('zero uncaught JavaScript errors',not errors,errors[:3])
report={'environment':'Chromium 844x390 touch; actual THREE.Sprite and source-PNG decoding; simulated WebGLRenderer (NO GPU/Safari claim)',
 'passed':sum(x['pass'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['pass']],
 'pageErrors':errors,'checks':checks}
(out/'effects-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print('BATCH15B EFFECTS',report['passed'],'/',report['total'],'errors',len(errors),flush=True)
sys.exit(1 if report['failed'] else 0)
