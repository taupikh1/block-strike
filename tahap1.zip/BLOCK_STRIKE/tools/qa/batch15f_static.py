#!/usr/bin/env python3
"""Batch 15F static deployment and source integrity checks (no browser GPU claim)."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse
import json,subprocess,re,sys,struct,wave
root=Path(__file__).resolve().parents[2]
checks=[]
def ck(name,ok,detail=None):
 checks.append({'name':name,'passed':bool(ok),'detail':detail});print('PASS' if ok else 'FAIL',name,flush=True)
html=(root/'index.html').read_text()
class References(HTMLParser):
 def __init__(self):super().__init__();self.local=[];self.external=[]
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  for k in ('src','href'):
   if k in d and d[k] and not d[k].startswith(('#','data:')):
    v=d[k].split('?')[0]
    if re.match(r'^https?://',v):self.external.append(v)
    else:self.local.append(v)
p=References();p.feed(html)
missing=[ref for ref in p.local if not (root/ref).is_file()]
ck('HTML script and stylesheet links resolve',not missing,missing[:10]);ck('Game runtime scripts/styles are local',not any(re.search(r'<(?:script|link)\b[^>]*(?:src|href)=[\"\']https?://',html,re.I) for _ in [0]),{'external_attribution_links':p.external})
ck('Static GitHub Pages entrypoint', (root/'index.html').exists() and (root/'.nojekyll').exists())
ck('Only shipped map has source JSON', (root/'assets/maps/dust_block.json').is_file())
ck('iPhone viewport-fit and A2HS metadata','viewport-fit=cover' in html and 'apple-mobile-web-app-capable' in html)
ck('Safe-area variables exist in CSS',all(x in (root/'css/classic.css').read_text() for x in ['safe-area-inset-left','safe-area-inset-right','safe-area-inset-bottom']))
jsfiles=list((root/'js').rglob('*.js'))
syntax_errors=[]
for f in jsfiles:
 r=subprocess.run(['node','--check',str(f)],text=True,capture_output=True)
 if r.returncode:syntax_errors.append({'name':str(f.relative_to(root)),'stderr':r.stderr[-300:]})
ck('Node.js syntax validation for all local JS',not syntax_errors,{'count':len(jsfiles),'errors':syntax_errors})
models=list((root/'assets/models/weapons').glob('shield_*.glb'))
expected={'shield_deagle','shield_fiveseven','shield_flashbang','shield_glock18','shield_hegrenade','shield_knife','shield_p228','shield_smokegrenade','shield_usp'}
ck('Nine native combined shield rigs plus generic shield', expected.issubset({x.stem for x in models}) and (root/'assets/models/weapons/shield_r.glb').is_file(),{'found':len(models),'missing':sorted(expected-{x.stem for x in models})})
corrupt=[]
for f in models:
 try:
  b=f.read_bytes();magic,ver,ln=struct.unpack_from('<III',b)
  if magic!=0x46546c67 or ver!=2 or ln!=len(b):corrupt.append(f.name)
 except Exception:corrupt.append(f.name)
ck('Shield GLB container headers valid',not corrupt,corrupt)
fx=root/'assets/cs16-grenade-fx';m=json.loads((fx/'manifest.json').read_text());sprite_counts={'he-flame':3,'he-dust':10,'flash-core':1,'smoke':12};wrong={k:len(list(fx.glob(k+'-*.png'))) for k,n in sprite_counts.items() if len(list(fx.glob(k+'-*.png')))!=n};ck('Grenade sprite files and manifest',not wrong and all(k in m for k in sprite_counts),wrong)
ck('Original Google Drive archives excluded',not any(root.rglob('cs16_files-*.zip')))
ck('No Git or dependency folder in deployment',not any(root.rglob('node_modules')) and not any(root.rglob('.git')))
report={'passed':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks,'scope':'Filesystem, JS syntax, deployment refs and asset headers only; not GPU/Safari QA.'}
output=root/'qa/batch15f/static-results.json';output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(report,indent=2,ensure_ascii=False))
print('BATCH15F STATIC',report['passed'],'/',report['total'])
sys.exit(0 if report['passed']==report['total'] else 1)
