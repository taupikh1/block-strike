#!/usr/bin/env python3
"""Batch 15A: test actual ZIP 02 shield GLBs and near-plane safety using Three.js loader.
No claims of real WebGL or physical Safari rendering are made by this test.
"""
from pathlib import Path
import base64,json,sys
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]
out=root/'qa/batch15a';out.mkdir(exist_ok=True)
models=['shield_usp','shield_glock18','shield_p228','shield_deagle','shield_fiveseven',
        'shield_knife','shield_hegrenade','shield_flashbang','shield_smokegrenade']
pistols={'shield_usp','shield_glock18','shield_p228','shield_deagle','shield_fiveseven'}
files={n:base64.b64encode((root/'assets/models/weapons'/f'{n}.glb').read_bytes()).decode() for n in models}
html=''.join('<script>'+ (root/'js/vendor'/s).read_text()+'</script>' for s in ['three.min.js','GLTFLoader.js','SkeletonUtils.js'])
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':844,'height':390});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content('<html><head>'+html+'</head><body></body></html>')
 results=page.evaluate('''async({files,pistols})=>{
  const results=[];const ok=(name,pass,info)=>results.push({name,pass:!!pass,info});
  const camera=new THREE.PerspectiveCamera(65,844/390,.01,10);camera.updateProjectionMatrix();camera.updateMatrixWorld();
  for(const [key,b64] of Object.entries(files)){
   const bin=Uint8Array.from(atob(b64),x=>x.charCodeAt(0));
   const gl=await new Promise((yes,no)=>new THREE.GLTFLoader().parse(bin.buffer,'',yes,no));
   const names=gl.animations.map(x=>x.name);
   const expected=pistols.includes(key)?['idle1','shoot1','reload','draw','shield_idle','shield_up','shield_down']:
     key==='shield_knife'?['idle','slash','hit','deploy','shield_up','shield_down']:
     ['idle1','pullpin','throw','draw','shield_up','shield_down'];
   ok(key+' original animation set',expected.every(x=>names.includes(x)),{names});
   const model=THREE.SkeletonUtils.clone(gl.scene);model.position.set(.24,-.12,(key.includes('grenade')||key==='shield_flashbang')?-.60:-.48);
   const meshes=[];model.traverse(x=>{if(x.isMesh)meshes.push(x)});
   ok(key+' real skinned geometry + materials',meshes.length>3&&meshes.every(x=>x.material?.name&&x.geometry?.attributes?.position?.count>0),{meshes:meshes.length});
   const mixer=new THREE.AnimationMixer(model);let worst=-99,near=0,vertexSamples=0;
   for(const clip of gl.animations){
    const samples=[0,Math.min(.12,clip.duration*.35),Math.min(.33,clip.duration*.8)];
    for(const time of samples){
     mixer.stopAllAction();mixer.setTime(0);mixer.clipAction(clip).reset().play();mixer.update(time);model.updateMatrixWorld(true);
     model.traverse(x=>{if(!x.isMesh)return;const attr=x.geometry.attributes.position;
      for(let i=0;i<attr.count;i++){
       const v=new THREE.Vector3().fromBufferAttribute(attr,i);if(x.isSkinnedMesh)x.boneTransform(i,v);v.applyMatrix4(x.matrixWorld);
       worst=Math.max(worst,v.z);vertexSamples++;if(v.z>=camera.near*-1)near++;
      }
     });
    }
   }
   ok(key+' animated camera near-plane clear',near===0,{near,vertexSamples,maxZ:worst});
  }
  return results;
 }''',{'files':files,'pistols':list(pistols)})
 b.close()
report={'type':'GLTFLoader real GLB, CPU animation/near-plane checks; no WebGL renderer','passes':sum(x['pass'] for x in results),'total':len(results),'failed':[x for x in results if not x['pass']],'pageErrors':errors,'results':results}
(out/'native-assets-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print('BATCH15A REAL ASSET:',report['passes'],'/',report['total'],'PAGE ERRORS',len(errors))
for item in report['failed']:print('FAIL',item)
sys.exit(0 if not report['failed'] and not errors else 1)
