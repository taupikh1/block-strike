'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Spec=require('../../js/spectator15e.js');
const bot=(team='CT',hp=100,extra={})=>({team,hp,dead:hp<=0?1:0,g:{parent:{},position:{x:0,z:0}},...extra});
test('six camera modes keep their documented order',()=>{
 assert.deepEqual(Spec.modeIds,['first','locked','chase','free','map','chase-map']);
 assert.equal(Spec.nextMode('chase-map'),'first');
 assert.equal(Spec.nextMode('first',-1),'chase-map');
 assert.equal(Spec.MODES[0].label,'First Person');
});
test('spectator targets teammates only, excludes dead and detached bot meshes',()=>{
 const a=bot(),enemy=bot('T'),dead=bot('CT',0),detached=bot('CT');detached.g.parent=null;
 const b=bot('CT');const source=[a,enemy,dead,detached,b];
 assert.deepEqual(Spec.teammates(source,'CT'),[a,b]);
 assert.equal(Spec.nextBot(source,'CT',null),a);
 assert.equal(Spec.nextBot(source,'CT',a,1),b);
 assert.equal(Spec.nextBot(source,'CT',b,1),a);
 assert.equal(Spec.nextBot(source,'CT',a,-1),b);
 assert.equal(Spec.nextBot(source,'T',a),enemy);
 assert.equal(Spec.nextBot(source,'X',a),null);
});
test('director follows a teammate in combat and retains current target on ties',()=>{
 const now=10000,a=bot('CT'),enemy=bot('T'),b=bot('CT',80,{visibleEnemy:{pos:{x:4,z:1}},lastShot:{at:9000}});
 assert.equal(Spec.director([a,enemy,b],'CT',a,now),b);
 assert.equal(Spec.director([a,b],'CT',b,now),b);
 b.visibleEnemy=null;b.lastShot=null;
 assert.equal(Spec.director([a,b],'CT',a,now),a);
 assert.equal(Spec.director([enemy],'CT',a,now),null);
});
test('clamping camera pitch, altitude, map zoom',()=>{
 assert.equal(Spec.clamp(200,18,110),110);
 assert.equal(Spec.clamp(-8,0,1.3),0);
 assert.equal(Spec.clamp(.6,0,1.3),.6);
});
