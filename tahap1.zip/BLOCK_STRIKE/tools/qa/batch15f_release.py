#!/usr/bin/env python3
"""Batch 15F end-to-end regression at multiple desktop/mobile viewport sizes.
Runs real game JS/DOM/Three scene math, but an explicitly mocked WebGL renderer
and model/image fetchers. Not a physical device or real shader/GPU test.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,re,sys,traceback
root=Path(__file__).resolve().parents[2]
report_file=root/'qa/batch15f/runtime-results.json'
report_file.parent.mkdir(parents=True,exist_ok=True)
html=(root/'index.html').read_text()
for src in re.findall(r'<link rel="stylesheet" href="([^"]+)">',html):
 html=html.replace(f'<link rel="stylesheet" href="{src}">','<style>\n'+(root/src).read_text()+'\n</style>')
map_json=json.dumps(json.loads((root/'assets/maps/dust_block.json').read_text()))
fetch_script='<script>window.fetch=async url=>String(url).includes("dust_block.json")?new Response('+json.dumps(map_json)+',{status:200}):new Response("",{status:404});</script>'
html=html.replace('<script src="js/vendor/three.min.js"></script>','<script>'+ (root/'js/vendor/three.min.js').read_text()+'</script>'+fetch_script)
for src in ['js/vendor/GLTFLoader.js','js/vendor/SkeletonUtils.js']:
 html=html.replace(f'<script src="{src}"></script>','<script>'+ (root/src).read_text()+'</script>')
mock='''<script>
THREE.WebGLRenderer=class{constructor(o){this.domElement=o.canvas;this.shadowMap={enabled:false};this.info={render:{frame:0,calls:0}};this.autoClear=true}setPixelRatio(){}setSize(){}render(){this.info.render.frame++;this.info.render.calls++}clearDepth(){}dispose(){}};
THREE.GLTFLoader.prototype.load=function(path,onLoad){const g=new THREE.Group(),bone=new THREE.Group();bone.name='Bip01_R_Hand';g.add(bone);queueMicrotask(()=>onLoad({scene:g,animations:[]}));return {}};
THREE.TextureLoader.prototype.load=function(){return new THREE.Texture()};
</script>'''
html=html.replace('<script src="js/bsp-render.js"></script>',mock+'<script src="js/bsp-render.js"></script>')
for src in re.findall(r'<script src="([^"]+)"></script>',html):
 html=html.replace(f'<script src="{src}"></script>','<script>\n'+(root/src).read_text()+'\n</script>')
assert '<script src=' not in html
checks=[];errors=[]
def check(name,ok,detail=''):
 checks.append({'name':name,'passed':bool(ok),'detail':str(detail)[:400]});print(('PASS' if ok else 'FAIL'),name,detail if not ok else '',flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
 for label,dimensions,mobile in [('iPhone13-landscape',{'width':844,'height':390},True),('compact-landscape',{'width':740,'height':360},True),('desktop',{'width':1280,'height':720},False)]:
  page=browser.new_page(viewport=dimensions,is_mobile=mobile,has_touch=mobile)
  e=[];page.on('pageerror',lambda x:e.append(str(x)))
  try:
   page.goto('about:blank');page.set_content(html,wait_until='load');page.wait_for_timeout(200)
   check(label+' main menu visible',page.locator('#menu').is_visible())
   page.locator('#go').click()
   page.locator('#matchPlayers').fill('8');page.locator('#matchPlayers').dispatch_event('change')
   page.locator('#continueMatchConfig').click();page.locator('[data-team="CT"]').click();page.locator('#startMatch').click()
   page.wait_for_function('running && bots.length===7 && !!R && !!vm',timeout=18000)
   page.evaluate('bots.forEach(b=>{b.cd=999;b.accuracy=0});P.hp=100')
   check(label+' full start flow',page.evaluate('round===1 && running && playerTeam==="CT" && bots.length===7'))
   check(label+' HUD present',page.locator('#hp').count()>0 and page.locator('#ammo').count()>0)
   check(label+' CT/T balanced',page.evaluate('bots.filter(b=>b.team==="CT").length===3&&bots.filter(b=>b.team==="T").length===4'))
   # Hold-fire, shield, grenade, weapon mode and scope must not corrupt the global game state.
   result=page.evaluate('''() => {
    const out={},initial=round;
    money=16000;buyTime=40;out.shieldPurchase=purchase('shield') && inventory.includes('shield');
    out.pistolShield=cur()==='shield'&&Phase9.shieldPistol()==='usp';
    out.shieldUp=Phase9.secondaryAction()!==false && Phase9.shieldRaised;
    Phase9.secondaryAction();out.shieldDown=!Phase9.shieldRaised;
    out.shieldInventoryCycle=Phase14C.hasShield(inventory) && Phase14C.cycleIndex(inventory,wi,1,W)>=0;
    out.grenadeStock=(()=>{grenades.he=1;grenades.flash=1;grenades.smoke=1;return Phase9.getDebugState().smoke===0})()
    ;return out;
   }''')
   for k,v in result.items():check(label+' '+k,v)
   page.evaluate('() => {P.hp=0;Phase13.onDeath()}')
   check(label+' death enters spectator',page.evaluate('Phase13.isSpectating()'))
   for mode in ['first','locked','chase','free','map','chase-map']:
    page.locator('#specMode').select_option(mode)
    check(label+' spectator '+mode,page.evaluate('Phase13.getDebugState().specMode==='+json.dumps(mode)+' && Number.isFinite(cam.position.x)'))
   page.evaluate('() => {Phase13.queueTeam("T");startRound()}')
   check(label+' team switch next round',page.evaluate('playerTeam==="T" && round===2 && !Phase13.isSpectating()'))
   check(label+' T initial pistol',page.evaluate('inventory.includes("glock18") && cur()==="glock18"'))
   check(label+' regenerated team balance',page.evaluate('bots.length===7 && bots.filter(b=>b.team==="T").length===3 && bots.filter(b=>b.team==="CT").length===4'))
   # Repeat rounds and AI steps; verify no stale spectator/burst/modal states.
   phase=page.evaluate('''() => {let valid=true; for(let i=0;i<5;i++){
      startRound();for(let j=0;j<10;j++){for(const b of bots){b.cd=999;botUpdate(b,.05)}Phase9.update(.05);Phase13.updateSpectator(.05)}
      valid=valid&&bots.length===7&&!Phase13.isSpectating()&&!WeaponModes15C.active()
        &&bots.every(b=>Number.isFinite(b.g.position.x)&&Number.isFinite(b.g.position.z));
    }return {valid,round,botCount:bots.length};}''')
   check(label+' 5-round longevity',phase['valid'] and phase['round']==7,phase)
   # Cap match at 32, 31 AI agents; also test game reset without new page navigation.
   large=page.evaluate('''() => {Phase10.setConfig({players:32,difficulty:'hard'},false);newGame();
      for(const b of bots){b.cd=999;botUpdate(b,.08)}
      return {round,bots:bots.length,valid:bots.every(b=>Number.isFinite(b.g.position.x)&&Number.isFinite(b.g.rotation.y)),size:Phase10.config.players};}''')
   check(label+' 32-player reset',large['round']==1 and large['bots']==31 and large['valid'] and large['size']==32,large)
   check(label+' no JS errors',not e,e[:2])
   if label=='iPhone13-landscape':
    page.evaluate('Phase10.setConfig({players:8,difficulty:"normal"},false);newGame()')
    page.screenshot(path=str(root/'qa/batch15f/menu-game-mobile-simulated.png'))
  except Exception as ex:
   errors.append(label+': '+str(ex));check(label+' completed without exception',False,str(ex));
   try:page.screenshot(path=str(root/'qa/batch15f/'+label+'-failure.png'))
   except Exception:pass
  finally:
   errors.extend(e);page.close()
 browser.close()
report={'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks,'errors':errors,
'environment':'Chromium DOM + THREE mathematics, mocked WebGLRenderer/GLTFLoader/TextureLoader. No physical Safari or real GPU.'}
report_file.write_text(json.dumps(report,indent=2,ensure_ascii=False))
print('BATCH 15F',report['passed'],'/',report['total'],'ERRORS',len(errors),flush=True)
sys.exit(0 if report['passed']==report['total'] and not errors else 1)
