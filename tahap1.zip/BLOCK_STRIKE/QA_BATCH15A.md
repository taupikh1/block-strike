# BLOCK STRIKE — Batch 15A QA (2026-11-18)

**Verdict: PASS WITH GPU/SAFARI LIMITATIONS.** Real GLTFLoader, native animations and CPU camera projections were tested; the test browser has no functional WebGL context, so on-device rendering must still be checked.

| Test | Result | Basis |
|---|---:|---|
| Nine source-derived shield GLBs: clips, geometry and near-plane | **27/27 PASS** | Real GLTFLoader + AnimationMixer, animated CPU vertex sampling over all original clips, iPhone 13 landscape camera |
| Native GLB runtime integration: buy/pistol switching/shield/knife/HE | **25/25 PASS** | Chromium 844×390, real GLB decoding, simulated WebGL renderer; zero page errors |
| Shield inventory and weapon selection | **33/33 PASS** | Chromium simulation |
| Existing CS 1.6 menu + options | **48/48 PASS** | Chromium DOM |
| Create Game / match settings | **10/10 PASS** | Chromium simulation |
| Grenade behavior and resource lifecycle | **44/44 PASS** | Chromium simulation |
| Spectator 15E browser modes and director | **78/78 PASS** | Chromium simulation, mobile landscape and desktop |
| Spectator 15E Node unit tests | **4/4 PASS** | Node |
| Hold-fire, alternate-fire and touch regression | **34/34 PASS** | Chromium simulation |
| Original HE/Flash/Smoke GLB regression | **18/18 PASS** | Real GLTFLoader + AnimationMixer |
| Asset path validation | **PASS** | 40 animated first-person GLBs, 165 WAVs, 34 icons |
| Actual 3D WebGL rendering / Safari iPhone 13 physical | **NOT VERIFIED** | The sandbox browser cannot obtain WebGL context |

## White-plane diagnosis and confidence

1. The user reported a large white area shortly after buying/switching weapons and a box-like area near bots. The old native weapon camera origin contained vertices in front of the 0.01 near-plane, a concrete clipping hazard.
2. A separate shield and pistol GLB were previously overlaid; source ZIP 02 provides matched single-weapon shield models with original animation. The new runtime no longer performs the composition for those variants.
3. Invisible ray-hit proxies are now `colorWrite:false` and `depthWrite:false`; placeholder gear boxes remain disabled.
4. CPU vertex sampling verifies all nine new shield GLBs' sampled original clips stay behind the near-plane at the assigned offsets, including grenade animations.

**Residual uncertainty:** source geometry and simulated Chromium tests do not prove that all intermittent white shapes are gone on the user's actual screen. Test buying shield, switching between all five pistols, raising/lowering, knife, then grenade in Safari iPhone 13 landscape. Also change ordinary weapons several times. If it recurs, a screenshot or short recording around the specific frame will distinguish a viewmodel clip from a world texture or intentional flashbang effect.

## Reproducible checks

```sh
python tools/qa/batch15a_native_assets.py
python tools/qa/batch15a_runtime.py
python tools/qa/tahap14c.py
python tools/qa/cs16_menu15.py
python tools/qa/cs16_menu15_match.py
python tools/qa/tahap14d.py
python tools/qa/tahap14d_real_models.py
python tools/qa/spectator15e_browser.py
node --test tools/qa/spectator15e.test.cjs
python tools/qa/tahap14efg.py
python tools/qa/validate_assets.py
```
