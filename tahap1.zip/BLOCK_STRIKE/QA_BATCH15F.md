# Batch 15F — Final QA & Release

Date: 18 November 2026. Source baseline: **BLOCK_STRIKE_BATCH15CD_WEAPONS_BOTS**, which contains Batch 15A, 15B, 15C, 15D, 15E and the MENU15 release. Release verdict: **CONDITIONAL / READY FOR ON-DEVICE ACCEPTANCE**, not a certified Safari/WebGL pass.

## Reproduced QA in this release

| Test command | Result | Scope |
|---|---:|---|
| `python tools/qa/run15cd_regressions.py` | **12/12 suites PASS** | Menu 48/48; match setup 10/10; shield inventory 33/33; touchscreen/hold fire 34/34; spectator DOM 78/78 and unit 4/4; native shield assets 27/27 and runtime 25/25; grenade effects 48/48, grenade physics/regression 44/44, original grenade models 18/18; asset validation |
| `node tools/qa/batch15cd_unit.cjs` | **15/15 PASS** | Timed burst, short magazine, cancellation, AI navigation/recovery and movement math |
| `python tools/qa/batch15cd_browser.py` | **52/52 PASS** | Weapon modes, sniper scope, 8-/32-player match, bot states, mobile alternate fire and JavaScript errors; mobile 844×390 and desktop 1280×720 |
| `python tools/qa/batch15f_release.py` | **69/69 PASS** | Three viewport sizes: iPhone 13 landscape 844×390, compact landscape 740×360, desktop 1280×720; new game, CT/T, shield, grenades, 6 spectator modes, change CT→T next round, 5 successive rounds, reset to 32 players |
| `python tools/qa/batch15f_static.py` | **12/12 PASS** | Static entrypoint, local runtime resources, syntax all JS, shield GLB files, grenade sprite manifests, safe-area metadata, excludes source Drive ZIPs |

Run in project root with Python 3, Playwright/Chromium, Node.js 22 and packages required by the previous QA scripts (Pillow, NumPy). These are **development/QA requirements only**, not needed to play or deploy the static game.

### What the browser tests do and do not prove

- Chromium uses the **real game JavaScript, DOM, Three.js scene objects and math**, with a **simulated WebGLRenderer and selected GLTF/texture fetches**. Several native shield GLB and grenade PNG tests additionally parse/decode actual converted assets in memory.
- The sandbox could not open localhost (`net::ERR_BLOCKED_BY_ADMINISTRATOR`) and `canvas.getContext('webgl')` returned `null` in Chromium with software-rendering flags. **No real GPU shader/render or image-quality verdict is possible here.** Screenshots captured with the simulated renderer do **not** show the actual 3D game world and are not proof of gameplay visuals.
- **Safari iPhone 13 physical, Add to Home Screen standalone, audio playback through speakers, tactile multi-touch, GPU/performance and a complete human start-to-finish match have NOT been verified.** They require manual acceptance in that environment.
- Only Dust Block is selectable/shipped. Large 25–32-player matches and heuristic AI recovery need device-performance observation. Other BSP map behavior is not certified.
- Assets derived from original CS 1.6/mod material may be subject to third-party copyright or distribution restrictions; review `ASSET_NOTICES.md` before publishing.

## Final QA decision

No new source-code defect was reproduced during this QA pass. **No gameplay JS, CSS, models, or audio were intentionally changed in Batch 15F**. Changes comprise QA scripts, reports, release/install documentation, README/changelog updates and an updated `SHA256SUMS.txt` manifest. Existing behavior from 15A–15E is preserved.

**Gate to declare FULL PASS:** complete the device checklist `SAFARI_IPHONE13_QA_CHECKLIST.md` (ideally also desktop GPU), record results, and fix any verified device-only issues. Do not call this release GPU/Safari certified yet.

### Evidence

- `qa/batch15cd/unit-results.json`
- `qa/batch15cd/browser-results.json`
- `qa/batch15cd/regression-results.json` (previous generated result retained; rerun reconfirmed 12/12)
- `qa/batch15f/runtime-results.json`
- `qa/batch15f/static-results.json`
- `qa/batch15f/regression-rerun.log`, `qa/batch15f/weapon-bot-rerun.log`, `qa/batch15f/release-flow.log` (full current-run console transcripts)
- ZIP CRC and per-package content verification will be in the separate `BLOCK_STRIKE_BATCH15F_VERIFIKASI.json` alongside the downloads.
