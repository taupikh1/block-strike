# Audit Asset CS 1.6 Google Drive: Models & Resources

Source supplied by user: `cs16_files-01.zip`, `cs16_files-02.zip`; installation target: BLOCK STRIKE CS16 Extra Full + Classic Menu update.

## What is in cs16_files-02.zip?

- **308 file entries** inside `cs16_files/models/`: **179 `.mdl`**, **128 `.ztmp` cache/compressed copies**, and **one `.spr`**. Therefore 308 entries does **not** mean 308 distinct useful models.
- The 179 `.mdl` consist of **9 player models** (8 standard CT/T plus VIP), **18 shield combination models** (`p_shield_*` and `v_shield_*`), and **152 root-level MDLs**.
- Root-level model group contains **31 standard `p_` held models**, **31 standard `v_` first-person models**, **34 standard `w_` dropped/world models**, and remaining special/prop/map/hostage models.
- **46 file entries** inside `cs16_files/resource/`: **28 `.res` layout definitions**, **17 `.tga` images**, and **one `.txt` localization file**.

## Already integrated before this batch

- 8 classic CT/T character GLBs, selectable in Options.
- Game weapon-view/held/world GLBs, radio, weapon and environment sounds, HUD sprites, VGUI graphics, buy menu and team selection assets.
- 96 source `p_`/`v_`/`w_` weapon `.mdl` files from this Google Drive source were byte-identical to assets provided previously, so they were not reconverted unnecessarily.
- 56 VGUI images and 29 supplemental sounds in the first integration, plus 71 sprites, 21 UI images, 119 supplemental WAVs, 8 character models in the extra integration.

## Newly used in this menu update

- `resource/GameMenu.res`: menu commands and ordering (`New Game`, `Find Servers`, `Options`, `Quit`, `Resume`).
- `resource/CreateMultiplayerGameServerPage.res`, `resource/CreateMultiplayerGameGameplayPage.res`: New Game dialog field names and grouping.
- `resource/OptionsSubMultiplayer.res` and `resource/ClientScheme.res`: options sections and GoldSrc-era visual language.
- Existing converted `cs16-menu-background.jpg` for menu artwork. A screenshot from the already-supplied BLOCK STRIKE QA assets provides the Dust Block map thumbnail.
- All classic menus implemented as working browser HTML/CSS/JS, not by blindly copying `.res` files.

## Not yet active; do not claim otherwise

- `models/shield` has 18 individual `.mdl` models for pistol/grenade/knife and shield combinations, as well as 18 `.ztmp` files. These models **are not all integrated**. Shield rendering issues are explicitly reserved for Batch 15A; swapping them here might reintroduce the old oversized shield bug.
- VIP and hostage character/prop models, bomb/hostage mission assets, and map-specific scenery are not used: their game modes and/or maps are not implemented.
- Legacy server executable `.so`, DLLs, Metamod, AMX Mod X, cheat assets: not loaded, not necessary for Three.js, not bundled by this patch.
- Other `.res` layouts for engine-level features do not automatically bring over GoldSrc's engine behavior. Existing shooter code must implement browser equivalents.

## Limits / distribution

The result is an original HTML5 single-player game styled closer to CS 1.6. It is **not** an executable port of GoldSrc nor a complete clone. Original Valve assets may have licensing restrictions for public redistribution; check rights before publishing.
