# Block Strike — Batch 15F Final QA & Release (18 November 2026)

- Resumed from the complete Batch 15C+15D build, including 15A shield/white-plane mitigation, 15B grenade FX, 15C weapon modes, 15D bot AI, 15E spectator and MENU15.
- Re-ran all 12 inherited regression suites; all passed.
- Re-ran 15/15 unit and 52/52 browser integration checks from Batch 15C+15D.
- Added 69/69 release-flow checks across three landscape/desktop layouts: real JS/DOM/Three scene math but simulated renderer.
- Added 12/12 static deployment/resource/syntax checks, including 9 native combined shield models, 1 generic shield rig, and source-derived grenade sprite assets.
- Added reproducible 15F QA scripts, release documentation, device manual-acceptance checklist, and refreshed SHA-256 manifest.
- No gameplay, rendering, model, or sound files were changed during this QA-only batch; no new bug was substantiated by the completed checks.
- **Verdict: CONDITIONAL**, pending real GPU/WebGL rendering and iPhone 13 physical Safari/A2HS acceptance. Third-party asset redistribution must also be reviewed.
