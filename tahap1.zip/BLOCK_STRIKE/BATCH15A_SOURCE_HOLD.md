# Source archive hold: Batch 15A (Tactical Shield)

Reserved by the project owner on 2026-11-18. **Do not import or change shield gameplay in Batch 15E.**

| Original archive | Size (bytes) | Original owner-supplied Google Drive URL |
|---|---:|---|
| `cs16_files-01.zip` | 98,907,239 | https://drive.google.com/file/d/1MLE8LTfq1x7qWcvp17ryeGy7w0K4_MeR/view?usp=drivesdk |
| `cs16_files-02.zip` | 94,723,791 | https://drive.google.com/file/d/16KPfrwfEqn-HwRGFe6vGfTRZrYn9SSY8/view?usp=drivesdk |

Both archives passed ZIP CRC inspection in the source handover. `cs16_files-02.zip` contains 1,009 entries, with 21 `.mdl` models whose filenames refer to the shield: the classic `p_shield.mdl`, nine `p_shield_*` and nine `v_shield_*` combinations (pistols, knife, flash, HE and smoke), `v_shield_r.mdl`, and `w_shield.mdl`. Original GoldSrc `.mdl` files must be inspected, converted and validated before Three.js use, preserving animations when practical.

The archives remain in Google Drive; **they are not copied into the 15E distribution** to avoid inflating the release or changing the shield baseline. Batch 15A should resume from this manifest and confirm licensing/redistribution permissions before public deployment.
