# Batch 15E validation

Date: 2026-11-18

| Validation | Result | Notes |
|---|---:|---|
| Spectator decision logic (Node `node:test`) | 4 / 4 PASS | Mode order, teammate-only targeting, director ranking, clamping |
| Spectator browser runtime (Chromium, 844×390 and 1280×720) | 78 / 78 PASS | Simulated renderer/GLTF; 6 camera modes, HUD, auto director, manual target, movement, respawn, JS errors |
| Existing CS16 Menu regression | 48 / 48 PASS | Chromium DOM |
| Existing Create Game / match rules regression | 10 / 10 PASS | Chromium with simulated renderer |
| Existing grenade regression | 44 / 44 PASS | Chromium simulation |
| Existing shield inventory regression | 33 / 33 PASS | Chromium simulation; shield engine unchanged |
| `node --check` on game JS | PASS | All `.js` files checked |
| Real GPU/WebGL gameplay | NOT VERIFIED | Software runner cannot create a WebGL context |
| Physical iPhone 13 Safari A2HS | NOT VERIFIED | Requires on-device QA |

Test scripts:
- `node --test tools/qa/spectator15e.test.cjs`
- `python tools/qa/spectator15e_browser.py`
- `python tools/qa/cs16_menu15.py`
- `python tools/qa/cs16_menu15_match.py`
- `python tools/qa/tahap14d.py`
- `python tools/qa/tahap14c.py`

The browser harness inlines the exact current JS/CSS and uses a stub renderer and stub asset loader because localhost URLs and real WebGL contexts are blocked in the QA container. **Do not interpret this as a physical GPU or Safari pass.**

Only three existing runtime files were changed relative to MENU15: `index.html`, `js/game-core.js`, `js/game-systems13.js`; all remaining baseline files were retained byte-for-byte. Added code and docs are listed in the changelog.
