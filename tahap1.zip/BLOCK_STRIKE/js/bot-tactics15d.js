/* Batch 15D — bounded tactical movement that never accesses hidden enemy state. */
const BotTactics15D=(()=>{
 'use strict';
 const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
 function engage(bot,target,order){
  const p=bot.g.position,dx=target.x-p.x,dz=target.z-p.z,d=Math.hypot(dx,dz)||1;
  const ux=dx/d,uz=dz/d,hold=bot.radioOrder?.mode==='hold';
  if(hold)return {x:0,z:0};
  // Attack cautiously, avoid fighting inside another soldier's collision hull.
  let approach=d>17?1:d<7?-.55:d<11?-.12:0;
  if((bot.hp||100)<30&&d<16)approach=Math.min(approach,-.8);
  const side=(bot.strafe||1)*(d<24?.47:.20);
  return {x:ux*approach-uz*side,z:uz*approach+ux*side};
 }
 function separate(bot,others,scale=1){
  if(!bot||!others)return {x:0,z:0};
  const p=bot.g.position;let x=0,z=0;
  for(const ally of others){if(ally===bot||ally.dead||ally.team!==bot.team)continue;
   const dx=p.x-ally.g.position.x,dz=p.z-ally.g.position.z,d2=dx*dx+dz*dz;
   if(d2>.001&&d2<4){const weight=clamp((2-Math.sqrt(d2))/2,0,1);x+=dx/Math.sqrt(d2)*weight;z+=dz/Math.sqrt(d2)*weight}
  }
  const l=Math.hypot(x,z);return l>0?{x:x/l*Math.min(.8,l)*scale,z:z/l*Math.min(.8,l)*scale}:{x:0,z:0};
 }
 function recover(bot,requested,moved,speed,dt){
  if(!requested){bot.stuck=0;bot.recoveryTime=0;return false}
  const progress=moved>=Math.min(.025,speed*dt*.18);
  bot.stuck=progress?0:(bot.stuck||0)+dt;
  if(bot.recoveryTime>0)bot.recoveryTime=Math.max(0,bot.recoveryTime-dt);
  if(bot.stuck>.8){bot.stuck=0;bot.nav=null;bot.layoutNav=null;
   bot.strafe=-(bot.strafe||1);bot.recoveryTime=.65;return true}
  return false;
 }
 function sidestep(bot,x,z){
  if(!(bot.recoveryTime>0))return {x,z};
  const l=Math.hypot(x,z)||1,side=bot.strafe||1;
  return {x:x*.25-z/l*side*.95,z:z*.25+x/l*side*.95};
 }
 return Object.freeze({engage,separate,recover,sidestep});
})();
