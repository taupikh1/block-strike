/* Batch 15B: source-derived GoldSrc sprite effects for HE, Flash and Smoke.
 * Visuals only. Damage, blindness, collision, ownership and smoke LOS stay in
 * Grenade14D / Phase9. Shared textures, bounded sprites, explicit disposal.
 */
const GrenadeFX15B=(()=>{
 'use strict';
 const ROOT='assets/cs16-grenade-fx/';
 const COUNTS={'he-flame':3,'he-dust':10,'flash-core':1,smoke:12};
 const frames={};const bursts=[];
 let prepared=false,scene=null,fallback=null;
 const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
 function fallbackTexture(){
  if(fallback)return fallback;
  const c=document.createElement('canvas');c.width=c.height=64;
  const ctx=c.getContext('2d');if(!ctx)return null;
  const g=ctx.createRadialGradient(32,32,1,32,32,32);
  g.addColorStop(0,'rgba(240,240,235,0.78)');g.addColorStop(.37,'rgba(205,208,202,0.38)');g.addColorStop(1,'rgba(180,180,180,0)');
  ctx.fillStyle=g;ctx.fillRect(0,0,64,64);fallback=new THREE.CanvasTexture(c);
  return fallback;
 }
 function preload(){
  if(prepared)return;
  prepared=true;
  // All assets come from the user's cs16_files-02.zip GoldSrc .spr sources.
  for(const [kind,count] of Object.entries(COUNTS)){
   frames[kind]=[];
   for(let i=0;i<count;i++){
    const url=ROOT+kind+'-'+String(i).padStart(2,'0')+'.png';
    // Missing media must never break grenade damage or turn off smoke blocking.
    const texture=new THREE.TextureLoader().load(url,undefined,undefined,()=>{});
    texture.encoding=THREE.sRGBEncoding;
    frames[kind].push(texture);
   }
  }
 }
 function texture(kind,index){
  const arr=frames[kind]||[];
  const tex=arr[Math.min(arr.length-1,Math.max(0,index|0))];
  return tex?.image?.width?tex:fallbackTexture();
 }
 function createSprite(kind,color=0xffffff){
  const mat=new THREE.SpriteMaterial({map:texture(kind,0),color,transparent:true,opacity:0,depthWrite:false,depthTest:true});
  return new THREE.Sprite(mat);
 }
 function bind(sprite,kind,index){
  const map=texture(kind,index);
  if(map&&sprite.material.map!==map){sprite.material.map=map;sprite.material.needsUpdate=true}
 }
 function init(root){scene=root;preload()}
 function burst(kind,pos){
  if(!scene)return false;
  preload();
  const he=kind==='he',parts=[];
  // A narrow, short-lived bright core, followed by expanding native dust.
  const flames=he?2:1;
  for(let i=0;i<flames;i++){
   const s=createSprite(he?'he-flame':'flash-core',he?0xffd5a5:0xf0fbff);
   s.position.copy(pos).add(new THREE.Vector3(i*.15,.4+i*.1,0));s.scale.setScalar(.55);scene.add(s);
   parts.push({sprite:s,kind:he?'he-flame':'flash-core',delay:i*.025,duration:he?.24:.17,
    size:.8+i*.2,growth:he?2.3:2.6,peak:he?.95:1,dx:0,dy:.3});
  }
  // Flashbang is a brief pulse, not an HE fireball. Its player blindness is
  // applied separately by Grenade14D.flashExposure in Phase9.
  const count=he?9:4;
  for(let i=0;i<count;i++){
   const angle=i*2.39996323,r=.18+Math.sqrt((i+.5)/count)*.6;
   const s=createSprite('he-dust',he?0xb5aea1:0xd9dfdc);
   s.position.copy(pos).add(new THREE.Vector3(Math.cos(angle)*r,.12+((i*3)%5)*.12,Math.sin(angle)*r));
   s.scale.setScalar(.25);scene.add(s);
   parts.push({sprite:s,kind:'he-dust',delay:he?.08:.075,duration:he?.74:.40,
    size:he?.55:.26,growth:he?2.2:.85,peak:he?.6:.23,
    dx:Math.cos(angle)*(he?1.35:.4),dy:he?.55:.13,dz:Math.sin(angle)*(he?1.35:.4)});
  }
  bursts.push({age:0,parts,type:kind});return true;
 }
 function disposeBurst(effect){
  for(const item of effect.parts){scene?.remove(item.sprite);item.sprite.material.dispose()}
 }
 function update(dt){
  for(let j=bursts.length-1;j>=0;j--){
   const fx=bursts[j];fx.age+=dt;let alive=false;
   for(const p of fx.parts){
    const t=(fx.age-p.delay)/p.duration;
    if(t<0){p.sprite.visible=false;alive=true;continue}
    if(t>=1){p.sprite.visible=false;continue}
    alive=true;p.sprite.visible=true;
    bind(p.sprite,p.kind,Math.floor(t*COUNTS[p.kind]));
    const size=p.size+p.growth*t;p.sprite.scale.set(size,size,1);
    p.sprite.material.opacity=p.peak*(p.kind==='he-flame'?Math.pow(1-t,1.1):Math.pow(1-t,.75));
    // Original particle positions are kept, so updating dt can't accumulate drift.
    p.sprite.position.y+=(p.dy||0)*dt;
    p.sprite.position.x+=(p.dx||0)*dt;
    p.sprite.position.z+=(p.dz||0)*dt;
   }
   if(!alive){disposeBurst(fx);bursts.splice(j,1)}
  }
 }
 function smoke(pos,duration){
  if(!scene)return null;
  preload();
  const group=new THREE.Group();group.position.copy(pos);group.position.y=Math.max(.05,pos.y);scene.add(group);
  const particles=[];const count=20;
  for(let i=0;i<count;i++){
   const s=createSprite('smoke',0x9da49f);
   const angle=i*2.39996323,r=Math.sqrt((i+.5)/count);
   s.userData.smoke={dx:Math.cos(angle)*r,dz:Math.sin(angle)*r,
    dy:.1+((i*7)%13)/13,variant:((i*11)%17)/17,offset:i%6,frame:-1};
   s.position.set(0,.2,0);s.scale.setScalar(.01);group.add(s);particles.push(s);
  }
  return {mesh:group,particles,age:0,duration,radius:0};
 }
 function updateSmoke(c,dt){
  c.age+=dt;c.radius=Math.min(Grenade14D.TYPES.smoke.radius,c.age*1.75);
  const alpha=Grenade14D.smokeOpacity(c.age,c.duration);
  for(const s of c.particles){
   const p=s.userData.smoke;
   // Show the GoldSrc cloud expansion once; hold its densest frames while the
   // smoke screen is active instead of replaying the vanish animation.
   const frame=c.age<2.1?Math.min(9,Math.floor(c.age*5)+p.offset%2):6+(p.offset%5);
   if(frame!==p.frame){bind(s,'smoke',frame);p.frame=frame}
   const radius=c.radius,spread=radius*(.86+.25*p.variant);
   s.position.set(p.dx*spread,p.dy*.5+radius*(.2+p.dy*.22),p.dz*spread);
   const size=radius*(.78+.32*p.variant);s.scale.set(size,size,1);
   s.material.opacity=alpha*(.35+.13*p.variant);
  }
  return c.age<c.duration;
 }
 function removeSmoke(c){
  scene?.remove(c.mesh);
  for(const s of c.particles)s.material.dispose();
 }
 function reset(){
  for(const b of bursts)disposeBurst(b);
  bursts.length=0;
 }
 function debug(){return {burstCount:bursts.length,burstTypes:bursts.map(x=>x.type),
  spriteCount:bursts.reduce((n,x)=>n+x.parts.length,0),textureCounts:Object.fromEntries(Object.entries(COUNTS).map(([k,n])=>[k,n]))}}
 return Object.freeze({preload,init,burst,update,reset,smoke,updateSmoke,removeSmoke,debug});
})();
