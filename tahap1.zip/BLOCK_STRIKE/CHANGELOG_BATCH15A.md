# BLOCK STRIKE — Batch 15A: Tactical Shield and transient bright polygons

Date: 2026-11-18
Base: **Batch 15E Spectator**, not MENU15. Existing spectator modes, menus, audio, AI and grenade physics preserved.

## Native shield integration

- Converted the owner's nine original `cs16_files-02.zip` first-person shield models (`models/shield/v_shield_*.mdl`) to GLB using the repository's existing GoldSrc v10 conversion pipeline. Existing `p_shield_*` third-person source models were inspected but intentionally not installed on bots that do not wield a shield.
- Swapped the previous compositing workaround (generic `v_shield_r` plus independent pistol GLB) for one self-contained animated viewmodel for each selected pistol: USP, Glock18, P228, Deagle, and Five-SeveN. Original shield animations `shield_up`, `shield_down`, shoot, reload and deploy are preserved.
- Added the original paired shield+knife model, including its source `slash` and `hit` animation mapping. HE, Flash, and Smoke use their corresponding shield viewmodel while the owner is carrying a shield. Projectile physics and grenade controls were not changed.
- Variant-specific weapon cache prevents stale pistol meshes on purchases, pickups, rapid switches and reuse after switching away. The asynchronous loader will never replace a newer viewmodel if its original selection is no longer current.
- Lower the shield when leaving shield mode for the knife; restore the raised shield pose when returning or changing the pistol while raised.

## Bright plane / brief white obstruction hardening

- Native GoldSrc viewmodels at the original camera origin cross the near clipping plane; measured examples included USP, Deagle, AK47, AWP and shield. Added stable viewmodel offsets before draw/reload clips to avoid exposing near-plane slicing and huge polygons during weapon switches.
- Shield+pistol / shield+knife use a 0.48-unit rearward offset; shield+grenade use 0.60 units to accommodate pin/throw motion; other standard weapons use a 0.28-unit rearward offset, with 0.08 for knife.
- Invisible bot hit proxies no longer write into the color or depth buffer; collision and raycasting remain intact. Previously removed placeholder gear boxes were not reintroduced.
- This addresses identified *plausible sources* of the reported transient white polygon after a buy/switch and box-like artefact on bots; exact physical display reproduction was unavailable. **No unconditional claim of visual elimination on Safari/GPU is made.** Flashbang's intentional whiteout stays unchanged.

## Scope preservation

- No new maps, servers, online mode, bots-with-shields, or unrelated features.
- Batch 15B–15D gameplay and AI remain deferred; Batch 15E remains included.
- Source `.mdl` ZIPs are not bundled in the game. The nine resulting GLBs retain underlying third-party licensing limits (`ASSET_NOTICES.md`).

Verification: `QA_BATCH15A.md` and `qa/batch15a/*.json`.
