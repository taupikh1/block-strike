# BLOCK STRIKE — Batch 15B QA

**Conditional PASS.** Native-derived grenade visuals run in the browser simulation. Real WebGL and Safari on a physical iPhone remain unverified.

| Check | Result | Scope |
|---|---:|---|
| New Batch 15B source sprites and runtime integration | **48/48 PASS** | 26 PNGs decoded in Chromium; HE/Flash/Smoke world sprites, animation lifetime, visible smoke, ammo, reset, zero JS errors |
| Original grenade mechanics and player flow | **44/44 PASS** | Pin, throw, physics, detonation and resource cleanup; simulated renderer |
| Original three first-person grenade GLBs | **18/18 PASS** | Actual GLTFLoader, Three AnimationMixer, real model clips |
| Tactical Shield: source models and camera bounds | **27/27 PASS** | Real GLB data and CPU camera positions |
| Tactical Shield: runtime and viewmodel integration | **25/25 PASS** | Chromium with real shield GLBs and simulated renderer |
| Shield inventory | **33/33 PASS** | Chromium gameplay logic |
| CS16 Menu15 | **48/48 PASS** | Mobile and desktop Chromium simulation |
| New Game match settings | **10/10 PASS** | Chromium simulation |
| Spectator 15E | **78/78 PASS + 4/4 Node PASS** | Mobile landscape and desktop spectator with simulated renderer |
| Hold-to-fire and alternate controls | **34/34 PASS** | Chromium simulation |
| Local assets validation | **PASS** | 40 animated GLBs, 165 WAVs, 34 icons; new PNG source checks in 15B |
| Physical iPhone 13 Safari/WebGL GPU screenshot test | **NOT TESTED** | Chromium cannot create WebGL context even with SwiftShader flags |

## Defect diagnosis

Previous HE used a generic opaque/transparent sphere that merely expanded; Flash used a generic burst; Smoke always drew `black_smoke1.png` frame 0, a tiny spot in a 72×72 picture. The supplied source archive contains multi-frame GoldSrc explosion/dust/smoke sprites. Batch 15B uses selected source frames with distinct timing and soft alpha, while retaining original grenade mechanics.

The source `3dmflaora.spr` frame is fully opaque as decoded and would have produced a square white plane if shown directly on a billboard. Its derived PNG applies a radial alpha falloff so the pixel corners are transparent. **This fix is specific to the flash effect**, not a claim that every possible white-plane bug is solved on real hardware.

## Re-run tests

```sh
python tools/qa/batch15b_effects.py
python tools/qa/tahap14d.py
python tools/qa/tahap14d_real_models.py
python tools/qa/batch15a_native_assets.py
python tools/qa/batch15a_runtime.py
python tools/qa/tahap14c.py
python tools/qa/cs16_menu15.py
python tools/qa/cs16_menu15_match.py
python tools/qa/spectator15e_browser.py
node --test tools/qa/spectator15e.test.cjs
python tools/qa/tahap14efg.py
python tools/qa/validate_assets.py
```

## Physical-device checks needed

On iPhone 13 landscape, throw one of each grenade in an empty section of Dust Block. Confirm HE produces a short warm flash and drifting dust, Flashbang gives a brief world pulse with white-screen effect only when facing an exposed nearby detonation, and Smoke rapidly builds a dense gray cloud then dissipates. Repeat grenade throws while carrying shield, while switching between pistols, and after starting a new round. Also check that the HUD touch buttons remain reachable and no large white rectangular sprites appear.
