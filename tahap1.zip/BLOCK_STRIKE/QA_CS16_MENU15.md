# QA — BLOCK STRIKE CS 1.6 Classic Menu (Menu 15)

Date: 2026-11-18. Baseline: **BLOCK_STRIKE_CS16_EXTRA_FULL** (the last completed asset integration, not the unfinished separate spectator 15E work).

## Functional integration

- Main menu uses source-supplied GoldSrc `resource/GameMenu.res` order where supported (Resume Game, New Game, Find Servers, Options, Quit), adding Credits as an existing game option. `Find Servers` explicitly reports that browser game is offline only; Quit explains browsers cannot reliably close the tab.
- `Create Game` has real **Server / Game / CPU Player Options** tabs. Map selection is limited to the only playable map `Dust Block`; the user-provided Dust/Aztec BSPs are *not* installed in this task. Player count (2–32) and bot difficulty (Easy/Normal/Hard) call the existing Phase10 configuration. Round duration, buy duration and first-round money are bound into the actual game-core initialization.
- **Options** has PC-style tabs: Multiplayer, Keyboard, Mouse, Audio, Video, Voice, Touch. Real controls modify the corresponding runtime/persistent settings: nickname, classic character skins, hand preference, mouse/touch sensitivity, crosshair scale/color, sound volume, graphics quality, HUD scale, and crouch mode. Keyboard is a reference of **current keybindings**, not a fake remapping feature; voice chat is unavailable offline.
- Options `Cancel` and `X` revert unsaved edits, `OK` commits, `Defaults` can also be canceled. New Game `Cancel` restores pending bot and match-rule changes; continuing commits.
- Main menu, Create Game, and Options were screenshot-reviewed on **Chromium 844×390** landscape, with scrollable settings on short screens. These are real UI interactions in Chromium using JS and CSS from the game. Browser graphics/gameplay GPU not verified.

## Results

- **38/38 interactive menu tests** including settings cancel, defaults revert, start team selection, money/time/rules, bot number/difficulty, offline disclosure.
- **34/34** Tahap 13 regression; **33/33** shield inventory 14C; **44/44** grenade 14D; **34/34** mobile touch 14E/F; **30/30** shield viewmodel 14B; **113/113** 14A model audit; **27/27** combat unit regression.
- All main JavaScript files passed `node --check`; original weapon assets validator passed.
- Important: tests operate with a Chromium software/simulation harness, not physical Safari iPhone 13 or full GPU/WebGL playthrough. Layout and controls on real device still need manual QA. Previously reported shield, white-frame flash, grenade control, burst/scope and bot AI issues remain queued under 15A–15D. Spectator 15E was being built separately and is **not merged in this menu-only release**.

Verdict: **CONDITIONAL PASS** for menu/features under test, no claim of full in-game Safari verification.
