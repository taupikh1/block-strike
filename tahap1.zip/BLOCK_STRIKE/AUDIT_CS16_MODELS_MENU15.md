# Original Google Drive Models/Resource Audit

Source: user-provided `cs16_files-02.zip`. Actual files read directly from the ZIP, not inferred from filenames alone.

| Source folder | Regular files | Notes |
|---|---:|---|
| `models/` | 308 | Includes active `.mdl`, cached `.mdl.ztmp`, GoldSrc props, sprites, objective-mode assets, and other subfolders |
| `models/player/` (`.mdl`) | 9 | 8 CT/T classes and VIP. The 8 CT/T skins were converted in CS16_EXTRA; VIP is mode-specific and not wired to elimination mode |
| `models/shield/` (`.mdl`) | 18 | 9 v_shield + 9 p_shield models for particular weapons; their cached `.ztmp` counterparts (18) are not extra unique models. These shield variants are **not all active**. Reserved for the existing shield bug batch 15A |
| `resource/` | 46 | GameMenu.res, ClientScheme.res, Buy/Menu/Spectator/Scoreboard layouts. Existing `.res` data is GoldSrc KeyValues: it does not run natively in a browser |

The UI in this release maps menu commands and presentation cues from the **actual** `GameMenu.res` and already converted menu background, then connects to HTML/CSS/JS. The ZIP `resource/UI` and `models/shield` assets are retained as source reference data, but were **not all implemented as live gameplay assets** in this menu-only batch. Map props, hostage/VIP-specific models, and engine module binaries are excluded as previously requested.

Importing every `.mdl`, `.ztmp`, or `.res` blindly could duplicate already fixed geometry or break the shield. This work does not claim otherwise. Original Valve/third-party asset distribution permission remains unverified; deploy only after the rights review.
