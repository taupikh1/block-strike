# BLOCK STRIKE — Batch 15B: Grenade Detonation FX (18 November 2026)

Baseline: Batch 15A Shield (includes Batch 15E Spectator). No modifications to shield inventory, bot combat, map, or spectator code.

## Repairs

1. **HE:** Replaced a simplistic expanding bright sphere with a short native GoldSrc muzzleflash burst followed by animated debris/dust from `fast_wallpuff1.spr`. Sound, damage falloff, friendly fire and occlusion calculations remain unchanged.
2. **Flashbang:** Added a brief world-space flash and dust pulse derived from original `3dmflaora.spr` / `fast_wallpuff1.spr`, while retaining existing direction- and obstacle-sensitive player blindness and bot stun. Corrected the square sprite's *alpha edge* to prevent a solid white rectangle from appearing in the 3D scene. Actual white-screen blindness is still intentional only when a flash affects the player.
3. **Smoke:** The old smoke effect drew the almost-empty *first frame* of `black_smoke1.png` for every particle. Replaced it with 20 layered, animated, source-derived `black_smoke3.spr` frames that visibly grow and persist. Radius, ~17.5-second duration, smoke obstruction and gameplay logic have not changed.
4. **Lifecycle / performance:** One-time async preload of 26 small PNG frames, shared textures across all particles, bounded particle counts, and cleanup when effects expire or a round resets. Image decode failure uses a soft radial fallback rather than breaking grenade mechanics.
5. **Compatibility:** Native throw/pin/weapon animations, shield-equipped grenade handling, mouse/keyboard and mobile controls are preserved from 15A.

## Modified existing runtime files

- `index.html` loads `js/grenade-fx15b.js` before `game-systems9.js`.
- `js/game-systems9.js` delegates FX presentation and resets to `GrenadeFX15B`, with its original physics and damage left intact.

## New source-derived assets

`assets/cs16-grenade-fx/`: 26 frames and `manifest.json` documenting each original `.spr` path, selected frames, alpha mode and SHA-256, from the user's `cs16_files-02.zip` on Google Drive. The ZIP's original `.spr` files are not repackaged. No new external runtime dependency.

## Known limits

- Real Three object/sprite logic and image decoding were tested in Chromium with simulated WebGL; the sandbox cannot create a WebGL context.
- Pixel appearance, mobile GPU particle transparency and Safari iPhone 13 physical gameplay are not yet verified.
- The source game/mod assets remain third-party copyrighted material, not automatically licensed for public redistribution.
