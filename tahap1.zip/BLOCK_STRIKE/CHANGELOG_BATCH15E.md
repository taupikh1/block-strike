# BLOCK STRIKE — Batch 15E: Spectator CS 1.6
2026-11-18

## Implemented

- Preserves the existing dead-player teammate camera and next-round respawn behavior from Tahap 13.
- Six selectable spectator modes: First Person, Locked Chase, Free Chase, Free Look, Free Map Overview, Chase Map Overview.
- GoldSrc spectator resource-inspired HUD with subject name, team, HP, weapon, live CT/T counts, timer, camera selector and previous/next teammate buttons.
- Manual target selection is restricted to living teammates, not enemy bots. No living teammates produces an explicit waiting state.
- Auto Director selects active teammates using current sightings and recent shots; manual selection turns it off until explicitly enabled again.
- Keyboard: Left/Right for subjects; C cycles modes; 1–6 directly select a mode; P toggles Auto Director; WASD (free look or map), Space/Shift vertical movement (free look).
- Touch: mode select, prev/next, Auto Director, drag-to-orbit/look/pan, and a directional pad for free modes. Mouse wheel zoom in free map mode.
- First-person spectator weapon view is shown only in first-person; observed bot model is hidden only in that mode and restored in other modes/respawn.
- Chase camera includes wall-raycast distance adjustment; match reset and respawn clear camera state/inputs.
- No new maps, cheats, multiplayer servers, or changes to Batch 15A–15D shield, grenade, weapon-mode, and AI implementations.

## Changed runtime files

`index.html`, `js/game-core.js`, `js/game-systems13.js`, plus newly added `js/spectator15e.js` and `css/spectator15e.css`.

## Limitations

- Browser QA uses a simulated WebGL renderer/asset loader. GPU-rendered bot poses, WebGL fidelity, and physical iPhone 13 Safari remain unverified.
- Auto Director is a local action-based approximation, not Valve's original network spectator protocol.
- Existing GoldSrc source archive license/redistribution restrictions still apply.
