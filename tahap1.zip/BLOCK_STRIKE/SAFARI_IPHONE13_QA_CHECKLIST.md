# Manual acceptance checklist — iPhone 13 / Safari / Add to Home Screen

**These tests were not run by the coding environment.** Check each item on a physical iPhone 13 after deploying the ZIP contents to a static HTTPS host:

- [ ] In Safari landscape, open New Game and start an 8-player CT match; world, bots and viewmodel all render (not black/white).
- [ ] Add to Home Screen, launch in standalone landscape; verify the full available canvas and safe areas (notch, home indicator), without stretched sprites.
- [ ] Open all menu tabs and buy-menu lists; confirm scrolling and tap targets without iOS text selection/zoom.
- [ ] Move, fire (hold), reload, crouch, walk, jump, adjust aim and multi-touch at the same time.
- [ ] Buy Tactical Shield with USP, then Glock/Deagle/P228/Five-SeveN; raise/lower shield and swap pistol/knife.
- [ ] Buy/throw HE, Flashbang, Smoke with shield raised/lowered; observe throw/pin animation, timed explosion flash and smoke buildup/dispersal.
- [ ] Rapidly swap weapons after purchasing; watch for giant white polygons or clipping flashes in viewmodel or on bots.
- [ ] Switch Glock semi/burst and FAMAS auto/burst; verify 3 distinct shots, ammo count, sound, interrupted bursts.
- [ ] AWP/Scout scope twice, fire, unscope, reload; check scope overlay alignment and touch.
- [ ] Die and enter spectator; verify all six cameras, target cycle, Auto Director, and mobile free-look move controls.
- [ ] End a round, respawn; confirm weapon/camera controls resume and spectator visuals disappear.
- [ ] Change CT↔T during play; confirm change only on next round.
- [ ] Play a match with 16 bots and, separately, 31 bots; check stutters, AI stuck paths, audio dropouts and excessive memory usage.
- [ ] Test Safari browser reload and A2HS standalone reload; no stale cached assets or missing files.
- [ ] Confirm all effects/sounds and UI remain legible in both low/high graphics settings.

Record device iOS version, date, video/screenshots, expected vs actual and exact reproduction for any failure. Mark the 15F release FULL PASS only after this checklist (and a real GPU test) is completed.
