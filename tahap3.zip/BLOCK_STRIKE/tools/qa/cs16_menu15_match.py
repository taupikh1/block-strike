#!/usr/bin/env python3
"""Simulated WebGL boot: verifies new match options affect gameplay state."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,re,sys
ROOT=Path(__file__).resolve().parents[2]
html=(ROOT/'index.html').read_text()
for path in re.findall(r'<link rel="stylesheet" href="([^"]+)">',html):
 html=html.replace(f'<link rel="stylesheet" href="{path}">','<style>'+(ROOT/path).read_text()+'</style>')
mock='''<script>window.__map=__MAP__;window.fetch=async function(url){if(String(url).includes('dust_block.json'))return new Response(JSON.stringify(window.__map),{status:200});return new Response('',{status:404})};</script>'''.replace('__MAP__',json.dumps(json.loads((ROOT/'assets/maps/dust_block.json').read_text())))
html=html.replace('<script src="js/vendor/three.min.js"></script>','<script>'+(ROOT/'js/vendor/three.min.js').read_text()+'</script>'+mock)
for path in ['js/vendor/GLTFLoader.js','js/vendor/SkeletonUtils.js']:
 html=html.replace(f'<script src="{path}"></script>','<script>'+(ROOT/path).read_text()+'</script>')
mock='''<script>THREE.WebGLRenderer=class{constructor(o){this.domElement=o.canvas;this.shadowMap={enabled:false};this.info={render:{calls:1,frame:1},memory:{geometries:0,textures:0}}}setPixelRatio(){}setSize(){}render(){}clearDepth(){}clear(){}};
THREE.GLTFLoader.prototype.load=function(path,onLoad){const g=new THREE.Group(),bone=new THREE.Group();bone.name='Bip01_R_Hand';g.add(bone);queueMicrotask(()=>onLoad({scene:g,animations:[]}));return {}};
THREE.TextureLoader.prototype.load=function(){return new THREE.Texture()};</script>'''
html=html.replace('<script src="js/bsp-render.js"></script>',mock+'<script src="js/bsp-render.js"></script>')
for path in re.findall(r'<script src="([^"]+)"></script>',html):
 html=html.replace(f'<script src="{path}"></script>','<script>'+ (ROOT/path).read_text()+'</script>')
assert '<script src=' not in html
checks=[];errors=[]
def ck(label,val):
 checks.append((label,bool(val)));print(('PASS' if val else 'FAIL'),label,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
 page=b.new_page(viewport={'width':844,'height':390},is_mobile=True,has_touch=True)
 page.on('pageerror',lambda e: errors.append(str(e)))
 page.goto('about:blank');page.set_content(html,wait_until='load');page.wait_for_timeout(150)
 page.locator('#go').click();page.locator('[data-create-tab="game"]').click()
 page.locator('#matchRoundTime').select_option('180');page.locator('#matchBuyTime').select_option('30');page.locator('#matchStartMoney').select_option('3000')
 page.locator('[data-create-tab="cpu"]').click();page.locator('#matchBotCount').fill('5');page.locator('#matchBotCount').dispatch_event('change');page.locator('#matchDifficulty').select_option('hard')
 page.locator('#continueMatchConfig').click();page.locator('[data-team="CT"]').click();page.locator('#startMatch').click();page.wait_for_timeout(600)
 ck('Match starts from CS16 Create Game dialog',page.evaluate('running&&round===1'))
 ck('New Game starting money works',page.evaluate('money===3000'))
 ck('Round timer and buy timer work',page.evaluate('roundTime>170&&roundTime<=180&&buyTime>20&&buyTime<=30'))
 ck('Bot count and difficulty affect actual roster',page.evaluate('bots.length===5&&Phase10.config.difficulty==="hard"'))
 ck('Second round keeps new configured timers',page.evaluate('(()=>{startRound();return buyTime===30&&roundTime===180&&round===2})()'))
 # In-game settings must use the same menu as the main screen, and resume afterwards.
 page.locator('#settingsGameBtn').click()
 ck('In-game settings opens actual six-tab Options dialog',page.locator('#settingsScreen').is_visible())
 ck('Gameplay pauses while Options open',page.evaluate('running===false'))
 page.locator('[data-options-tab="video"]').click();page.locator('#q').select_option('0')
 page.locator('#optionsApply').click()
 ck('Closing Options resumes gameplay',page.evaluate('running===true&&!document.querySelector("#settingsScreen").classList.contains("hidden")===false'))
 ck('Video quality applies to existing renderer',page.evaluate('Q===0'))
 ck('No uncaught JS errors',not errors)
 b.close()
report={'passed':sum(v for _,v in checks),'total':len(checks),'failed':[k for k,v in checks if not v],'page_errors':errors,'environment':'Chromium mobile DOM with WebGL renderer and GLTF load stubbed.'}
(ROOT/'qa/cs16-menu15/match_results.json').write_text(json.dumps(report,indent=2))
print('RESULT',report['passed'],'/',report['total'])
sys.exit(0 if report['passed']==report['total'] else 1)
