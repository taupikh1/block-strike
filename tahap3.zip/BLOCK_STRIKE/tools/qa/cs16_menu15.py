#!/usr/bin/env python3
"""CS 1.6 style menu smoke test using real Chromium DOM and JS, without GPU.
The sandbox prevents local URL navigation, so scripts and styles are injected from
this project's exact files. This verifies UI wiring but not a rendered 3D match.
"""
import re,json,base64,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2]
html=(ROOT/'index.html').read_text()
styles=re.findall(r'<link\s+rel="stylesheet"\s+href="([^"]+)"',html)
scripts=re.findall(r'<script\s+src="([^"]+)"\s*>\s*</script>',html)
html=re.sub(r'<script\s+src="[^"]+"\s*>\s*</script>','',html)
html=re.sub(r'<link\s+rel="stylesheet"\s+href="[^"]+">','',html)
results=[];errors=[]
def check(name,ok):
 results.append({'name':name,'pass':bool(ok)})
 print(('PASS ' if ok else 'FAIL ')+name,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for viewport in [(844,390),(1365,768)]:
  page=b.new_page(viewport={'width':viewport[0],'height':viewport[1]},has_touch=True,is_mobile=viewport[0]<900)
  page.on('pageerror',lambda err:errors.append(str(err)))
  page.set_content(html,wait_until='domcontentloaded')
  for style in styles:
   path=ROOT/style
   if path.exists():page.add_style_tag(content=path.read_text(errors='replace'))
  bg=ROOT/'assets/cs16-extra-ui/cs16-menu-background.jpg'
  if bg.exists():
   url='data:image/jpeg;base64,'+base64.b64encode(bg.read_bytes()).decode('ascii')
   page.add_style_tag(content='#menu{background-image:linear-gradient(90deg,rgba(11,18,26,.56),rgba(0,0,0,.05)),url('+url+')!important}')
  for script in scripts:page.add_script_tag(content=(ROOT/script).read_text(errors='replace'))
  page.wait_for_timeout(140)
  label=f'{viewport[0]}x{viewport[1]}'
  check(label+' menu visible',page.locator('#menu').is_visible())
  check(label+' New Game / Options / Offline browser present',all(page.locator('#'+n).is_visible() for n in ['go','settingsBtn','findServersBtn']))
  check(label+' menu stays inside viewport',page.evaluate('()=>{const r=document.querySelector("#menu .cs-classic-main").getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight}'))
  page.locator('#findServersBtn').click()
  check(label+' server browser honestly offline','offline' in page.locator('#offlineNotice').inner_text().lower())
  page.locator('#go').click()
  check(label+' Create Game opens',page.locator('#matchConfigScreen').is_visible())
  check(label+' only actually loaded map offered',page.locator('#createMap option').count()==1 and page.locator('#createMap').input_value()=='dust_block')
  page.locator('#matchPlayers').fill('20');page.locator('#matchPlayers').dispatch_event('change')
  check(label+' player count connected to AI',page.evaluate('Phase10.config.players===20&&Number(document.getElementById("matchBotCount").value)===19'))
  page.locator('[data-create-tab="cpu"]').click();page.locator('#matchBotCount').fill('13');page.locator('#matchBotCount').dispatch_event('change')
  page.locator('#matchDifficulty').select_option('hard')
  check(label+' bot count and hard difficulty persist in AI',page.evaluate('Phase10.config.players===14&&Phase10.config.difficulty==="hard"'))
  page.locator('[data-create-tab="game"]').click()
  page.locator('#matchRoundTime').select_option('180');page.locator('#matchStartMoney').select_option('3000');page.locator('#matchBuyTime').select_option('30')
  check(label+' game rules saved',page.evaluate('PhaseMenu15.rules.roundSeconds===180&&PhaseMenu15.rules.startMoney===3000&&PhaseMenu15.rules.buyTime===30'))
  page.locator('#continueMatchConfig').click()
  check(label+' New Game continues to CT/T team selection',page.locator('#teamScreen').is_visible())
  page.locator('#backMenu').click();page.locator('#backMatchConfig').click()
  page.locator('#settingsBtn').click();check(label+' Options opens',page.locator('#settingsScreen').is_visible())
  for tab in ['multiplayer','keyboard','mouse','audio','video','touch']:
   page.locator(f'[data-options-tab="{tab}"]').click()
   check(label+' Options '+tab+' panel visible',page.locator(f'[data-options-panel="{tab}"]').is_visible())
  page.locator('[data-options-tab="multiplayer"]').click()
  page.locator('#playerNickname').fill('TEST PLAYER')
  check(label+' nickname propagated to scoreboard source',page.evaluate('PhaseMenu15.playerName==="TEST PLAYER"'))
  page.locator('[data-options-tab="mouse"]').click()
  page.locator('#sn').fill('0.0055');page.locator('#sn').dispatch_event('input')
  page.locator('#crosshairSize').fill('30');page.locator('#crosshairSize').dispatch_event('input')
  check(label+' mouse sensitivity affects gameplay',page.evaluate('SENS===0.0055'))
  check(label+' crosshair size affects visible HUD',page.evaluate('getComputedStyle(document.querySelector("#cross")).width==="30px"'))
  page.locator('[data-options-tab="audio"]').click();page.locator('#volume').fill('0.35');page.locator('#volume').dispatch_event('input')
  check(label+' audio master volume reacts',page.evaluate('masterVolume===0.35'))
  page.locator('#optionsApply').click();check(label+' Options closes on OK',not page.locator('#settingsScreen').is_visible())
  page.locator('#quitBtn').click();check(label+' browser Quit dialog is honest',page.locator('#quitDialog').is_visible() and 'tab' in page.locator('#quitDialog p').inner_text())
  page.locator('#quitBack').click()
  check(label+' no JS errors',not errors)
  page.close()
 b.close()
report={'passed':sum(x['pass'] for x in results),'total':len(results),'failed':[r for r in results if not r['pass']],'browser_errors':errors,'environment':'Chromium DOM with exact local assets injected; no WebGL or physical Safari.'}
(ROOT/'qa/cs16-menu15').mkdir(parents=True,exist_ok=True)
(ROOT/'qa/cs16-menu15/results.json').write_text(json.dumps(report,indent=2))
print('RESULT',report['passed'],'/',report['total'])
sys.exit(0 if report['passed']==report['total'] else 1)
