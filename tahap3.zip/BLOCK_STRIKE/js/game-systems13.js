/* BLOCK STRIKE Tahap 13: classic walk, spectator, flashlight, loadout UI,
   team changes, blood decals and persistent presentation settings. */
const Phase13=(()=>{
 'use strict';
 let spectating=false,observed=null,spectatorView=null,spectatorKey='',queuedTeam=null,deadThisRound=false;
 let specMode='first',autoDirector=true,directorClock=0,orbitYaw=0,orbitPitch=.33,freeYaw=0,freePitch=0,mapHeight=44;
 const freePos=new THREE.Vector3(),mapCenter=new THREE.Vector3(),specKeys={forward:false,back:false,left:false,right:false,up:false,down:false};
 let specGesture=null;

 let flashlight=null,flashTarget=null,lightEnabled=false,hand='right',returningToGame=false;
 const bloodDecals=[],bloodBursts=[];
 const moveSpeeds={knife:7.0,awp:4.0,scout:6.1,m249:4.65,shield:5.0,g3sg1:4.9,sg550:5.25,aug:5.35,sg552:5.4,ak47:5.55,m4a1:5.55};
 function moveSpeed(k){return moveSpeeds[k]||6.1}
 function isSpectating(){return spectating}
 function visibleOverlay(){return ['weaponOverlay','teamOverlay','settingsScreen'].some(id=>!$(id).classList.contains('hidden'))}
 function blocked(){return !running||spectating||visibleOverlay()||over}
 function applyHand(model){if(model)model.scale.x=hand==='left'?-Math.abs(model.scale.x||1):Math.abs(model.scale.x||1)}
 function setHand(next){hand=next==='left'?'left':'right';$('weaponHand').value=hand;applyHand(vm);applyHand(spectatorView);try{localStorage.setItem('bs13-weapon-hand',hand)}catch(e){}}
 function bindLight(camera){if(!camera)return;
  const light=new THREE.SpotLight(0xfff1cb,2.4,58,Math.PI/7,.45,1.15);
  light.visible=false;light.castShadow=false;light.position.set(0,-.07,.15);
  const target=new THREE.Object3D();target.position.set(0,-.08,-14);camera.add(light,target);light.target=target;
  flashlight=light;flashTarget=target;
 }
 function toggleFlashlight(){if(blocked())return false;lightEnabled=!lightEnabled;
  if(flashlight)flashlight.visible=lightEnabled;
  $('flashBtn').classList.toggle('active',lightEnabled);say(lightEnabled?'FLASHLIGHT ON':'FLASHLIGHT OFF');return true}
 function renderWeaponSelector(){const host=$('weaponItems');host.replaceChildren();
  const shield=Phase14C.hasShield(inventory),cats=shield?[[ 'PISTOL + SHIELD',['shield']],['KNIFE',inventory.filter(k=>k==='knife')]]:[['PRIMARY',inventory.filter(k=>W[k]?.slot==='primary')],['SECONDARY',inventory.filter(k=>W[k]?.slot==='pistol')],['KNIFE',inventory.filter(k=>k==='knife')]];
  for(const [label,weapons] of cats){if(!weapons.length)continue;
   const title=document.createElement('b');title.textContent=label;host.appendChild(title);
   for(const k of weapons){const button=document.createElement('button');button.className='weapon-choice';button.type='button';button.dataset.weapon=k;
    const img=document.createElement('img');img.src=CS16VGUI.icon(k)||'assets/ui/icons/'+k+'.png';img.alt='';img.onerror=()=>{img.hidden=true};button.append(img);
    const text=document.createElement('span');text.textContent=k==='shield'?W[Phase14C.pistol(inventory)||'usp'].n+' + SHIELD':W[k].n;button.append(text);
    if(k===cur())button.classList.add('active');button.addEventListener('click',()=>{const i=inventory.indexOf(k);if(i>=0)setW(i);closeWeaponSelector()});host.appendChild(button)
   }
  }
  const g=document.createElement('b');g.textContent='GRENADES';host.append(g);
  for(const type of ['he','flash','smoke']){const b=document.createElement('button');b.className='weapon-choice';b.disabled=!grenades[type];b.textContent=`${type.toUpperCase()} · ${grenades[type]}`;b.onclick=()=>{selectedGrenade=type;Phase9.updateHud();closeWeaponSelector()};host.append(b)}
 }
 function closeWeaponSelector(){$('weaponOverlay').classList.add('hidden')}
 function openWeaponSelector(){if(!running||spectating)return;Phase10.closeRadio();renderWeaponSelector();$('weaponOverlay').classList.remove('hidden')}
 function closeTeamMenu(){$('teamOverlay').classList.add('hidden')}
 function openTeamMenu(){if(!running)return;Phase10.closeRadio();$('teamOverlay').classList.remove('hidden');$('teamQueued').textContent=queuedTeam?'Queued: '+queuedTeam:''}
 function queueTeam(team){if(team!=='CT'&&team!=='T')return false;queuedTeam=team===playerTeam?null:team;closeTeamMenu();say(queuedTeam?`SWITCH TO ${queuedTeam} NEXT ROUND`:'TEAM SWITCH CANCELLED');return true}
 // The reference GoldSrc UI supplies playerprev/playernext, mode and Auto Director controls.
 // Actual Three.js cameras are local single-player equivalents, not network observers.
 function clearSpecWeapon(){
  spectatorKey='';if(spectatorView){viewScene?.remove(spectatorView);spectatorView=null}
 }
 function resetSpecView(){if(observed?.g)observed.g.visible=true;observed=null;clearSpecWeapon()}
 function resetSpecMovement(){for(const key of Object.keys(specKeys))specKeys[key]=false;specGesture=null}
 function resetMatch(){spectating=false;deadThisRound=false;queuedTeam=null;resetSpecView();resetSpecMovement();specMode='first';autoDirector=true;directorClock=0;mapHeight=44;
  $('specMode').value='first';$('spectatorHud').classList.add('hidden');$('spectatorTop').classList.add('hidden');$('spectatorMove').classList.add('hidden');document.body.classList.remove('spectating');
  lightEnabled=false;if(flashlight)flashlight.visible=false;$('flashBtn').classList.remove('active');clearBlood()}
 function beforeRound(){const changed=!!queuedTeam&&queuedTeam!==playerTeam;
  if(changed){playerTeam=queuedTeam;playerClass=(playerTeam==='CT'?'gign':'arctic');Phase10.resetMatch();money=800}
  if(deadThisRound||changed){armor=0;helmet=false;defuseKit=false;nightVision=false;grenades={he:0,flash:0,smoke:0};
   inventory=[playerTeam==='CT'?'usp':'glock18','knife'];wi=0;
   for(const key of inventory)A[key]={mag:W[key].mag,res:W[key].res};
   setW(0);Phase9.resetMatch()}
  queuedTeam=null;spectating=false;deadThisRound=false;resetSpecView();resetSpecMovement();directorClock=0;
  $('spectatorHud').classList.add('hidden');$('spectatorTop').classList.add('hidden');$('spectatorMove').classList.add('hidden');document.body.classList.remove('spectating');
  if(vm)vm.visible=true;
  if(flashlight)flashlight.visible=lightEnabled;
  clearBlood();if(typeof Phase10!=='undefined')Phase10.preview();
 }
 function aliveBots(){return Spectator15E.teammates(bots,playerTeam)}
 function syncObservedVisual(){
  if(!observed)return;
  observed.g.visible=specMode!=='first';clearSpecWeapon();
  if(specMode==='first')loadSpectatorWeapon(observed);
 }
 function watchBot(next){
  if(next===observed)return next;
  if(observed?.g)observed.g.visible=true;
  observed=next;clearSpecWeapon();
  if(next)syncObservedVisual();
  return next;
 }
 function pickBot(direction=1,manual=false){
  const next=Spectator15E.nextBot(bots,playerTeam,observed,direction);
  watchBot(next);
  if(manual){autoDirector=false;directorClock=0}
  updateSpecHud();return next;
 }
 function loadSpectatorWeapon(bot){
  if(!bot||specMode!=='first')return;
  const id=bot.weaponId||'knife',expected=spectatorKey=id+'@'+(bot.botId||bot.name);
  ensureWeaponModel(id).then(g=>{
   if(!spectating||specMode!=='first'||observed!==bot||spectatorKey!==expected||!viewScene)return;
   if(spectatorView)viewScene.remove(spectatorView);
   const orig=weaponModels[id]?.scene||g,model=THREE.SkeletonUtils?.clone?THREE.SkeletonUtils.clone(orig):orig.clone(true);
   spectatorView=new THREE.Group();spectatorView.add(model);
   const clips=weaponModels[id]?.animations||[],idle=clips.find(c=>/idle/i.test(c.name))||clips[0];
   if(idle){const mixer=new THREE.AnimationMixer(model);mixer.clipAction(idle).play();spectatorView.userData.weaponMixer=mixer}
   applyHand(spectatorView);viewScene.add(spectatorView)
  }).catch(()=>{});
 }
 function setSpecMode(next){
  if(!Spectator15E.modeIds.includes(next))return false;
  const previous=specMode;specMode=next;resetSpecMovement();
  if(specMode==='chase'){orbitYaw=observed?.g.rotation.y||0;orbitPitch=.33}
  if(specMode==='free'&&previous!=='free'){
   freePos.copy(['map','chase-map'].includes(previous)&&observed?observed.g.position.clone().add(new THREE.Vector3(0,1.8,0)):cam.position);freeYaw=observed?.g.rotation.y??cam.rotation.y;freePitch=0;
  }
  if(specMode==='map'&&previous!=='map'){
   const ct=activeMapData?.spawn?.ct,t=activeMapData?.spawn?.t;
   mapCenter.set(ct&&t?(ct[0]+t[0])/2:0,0,ct&&t?(ct[2]+t[2])/2:0);
  }
  if(specMode==='first'||previous==='first')syncObservedVisual();
  $('specMode').value=next;updateSpecHud();return true;
 }
 function toggleDirector(next){autoDirector=typeof next==='boolean'?next:!autoDirector;directorClock=0;updateSpecHud();return autoDirector}
 function updateSpecHud(){
  if(!spectating)return;
  const list=aliveBots(),b=observed;
  const mode=Spectator15E.MODES.find(x=>x.id===specMode);$('specModeLabel').textContent=mode?.label.toUpperCase()||'SPECTATOR';
  $('specName').textContent=b?.name||(list.length?'SELECT TEAMMATE':'NO TEAMMATES ALIVE');
  $('specInfo').textContent=b?`${b.team} · HP ${Math.ceil(b.hp)} · ${W[b.weaponId]?.n||'KNIFE'}`:'Waiting for next round';
  $('specAuto').textContent=autoDirector?'AUTO ON':'AUTO OFF';$('specAuto').classList.toggle('active',autoDirector);
  $('specAuto').setAttribute('aria-pressed',String(autoDirector));
  $('specPrev').disabled=$('specNext').disabled=!list.length;
  $('spectatorMove').classList.toggle('hidden',!list.length||!['free','map'].includes(specMode));
  $('specHelp').textContent=specMode==='free'?'Drag to look · WASD / arrows to move · Space up · Shift down':specMode==='map'?'Drag / WASD to pan · Mouse wheel to zoom':'◀ ▶ teammate · C mode · P director';
  const ct=bots.filter(x=>!x.dead&&x.team==='CT').length+(playerTeam==='CT'&&P.hp>0?1:0);
  const t=bots.filter(x=>!x.dead&&x.team==='T').length+(playerTeam==='T'&&P.hp>0?1:0);
  $('specScores').textContent=`CT ${ct} ALIVE · T ${t} ALIVE`;
  $('specTime').textContent=`ROUND ${round} · ${Math.max(0,Math.ceil(roundTime))}s`;
 }
 function onDeath(){if(spectating)return;
  deadThisRound=true;spectating=true;aiming=false;zoomIdx=0;syncAim();directorClock=0;
  if(vm)vm.visible=false;if(flashlight)flashlight.visible=false;
  document.body.classList.add('spectating');$('spectatorHud').classList.remove('hidden');$('spectatorTop').classList.remove('hidden');
  setSpecMode('first');pickBot(0);say('ELIMINATED · SPECTATOR MODE');
 }
 function botAim(b,position){
  let yaw=b.g.rotation.y,pitch=0;
  if(b.visibleEnemy?.pos){const p=b.visibleEnemy.pos,dx=p.x-position.x,dz=p.z-position.z;
   yaw=Math.atan2(-dx,-dz);pitch=Math.atan2(position.y-(p.y+1.1),Math.hypot(dx,dz));}
  return {yaw,pitch:Spectator15E.clamp(pitch,-1.3,1.3)};
 }
 function chaseCam(target,yaw,pitch,distance){
  // Raycast from subject to desired viewpoint so walls don't obscure the observed bot.
  const offset=new THREE.Vector3(Math.sin(yaw)*Math.cos(pitch)*distance,Math.sin(pitch)*distance,Math.cos(yaw)*Math.cos(pitch)*distance);
  const desired=target.clone().add(offset),dir=desired.clone().sub(target),length=dir.length();
  let actual=length;
  if(length>.01&&obsM.length){ray.set(target,dir.normalize());ray.near=.12;ray.far=length;
   const hit=ray.intersectObjects(obsM,true).find(x=>x.distance>.15);
   if(hit)actual=Math.max(.24,hit.distance-.16);
   ray.near=0;
  }
  cam.position.copy(target).addScaledVector(dir.normalize(),actual);cam.lookAt(target);
 }
 function moveFree(dt){
  const forward=(specKeys.forward?1:0)-(specKeys.back?1:0),side=(specKeys.right?1:0)-(specKeys.left?1:0);
  const up=(specKeys.up?1:0)-(specKeys.down?1:0),length=Math.max(1,Math.hypot(forward,side,up));
  const speed=(specMode==='map'?18:10)*Math.min(dt,.05)/length;
  const dx=(-Math.sin(freeYaw)*forward+Math.cos(freeYaw)*side)*speed,dz=(-Math.cos(freeYaw)*forward-Math.sin(freeYaw)*side)*speed;
  if(specMode==='map'){mapCenter.x+=dx;mapCenter.z+=dz}
  else {freePos.x+=dx;freePos.z+=dz;freePos.y=Spectator15E.clamp(freePos.y+up*speed,1,100)}
 }
 function updateSpectator(dt){if(!spectating)return;
  if(!Spectator15E.alive(observed,playerTeam)){pickBot(1)}
  const b=observed;if(!b){updateSpecHud();return}
  directorClock+=Math.max(0,dt);
  if(autoDirector&&directorClock>=3.5){directorClock=0;const candidate=Spectator15E.director(bots,playerTeam,b,performance.now());
   if(candidate!==b)watchBot(candidate)}
  const subject=observed,base=subject.g.position,eye=base.clone().add(new THREE.Vector3(0,subject.crouching?1.14:1.57,0));
  if(specMode==='first'){
   if(spectatorView?.userData.weaponMixer)spectatorView.userData.weaponMixer.update(dt);
   cam.position.copy(eye);const aim=botAim(subject,cam.position);cam.rotation.set(aim.pitch,aim.yaw,0,'YXZ');
   const key=(subject.weaponId||'knife')+'@'+(subject.botId||subject.name);
   if(spectatorKey!==key){clearSpecWeapon();loadSpectatorWeapon(subject)}
  }else if(specMode==='locked'){
   chaseCam(eye,subject.g.rotation.y,.32,3.6);
  }else if(specMode==='chase'){
   chaseCam(eye,orbitYaw,orbitPitch,4.5);
  }else if(specMode==='free'){
   moveFree(dt);cam.position.copy(freePos);cam.rotation.set(freePitch,freeYaw,0,'YXZ');
  }else if(specMode==='map'){
   moveFree(dt);cam.position.set(mapCenter.x,mapHeight,mapCenter.z);cam.rotation.set(-Math.PI/2,0,0,'YXZ');
  }else if(specMode==='chase-map'){
   cam.position.set(base.x,base.y+34,base.z);cam.rotation.set(-Math.PI/2,subject.g.rotation.y,0,'YXZ');
  }
  if(cam.fov!==baseFov){cam.fov=baseFov;cam.updateProjectionMatrix()}
  if(window.bspSky)window.bspSky.position.copy(cam.position);
  // HUD state changes are inexpensive; batch with the game frame rather than forcing layout on pointermove.
  hudSpecClock+=dt;if(hudSpecClock>.15){hudSpecClock=0;updateSpecHud()}
 }
 let hudSpecClock=0;
 function shouldRenderSpecWeapon(){return spectating&&specMode==='first'&&!!spectatorView}
 function checkRoundEnd(){if(!running||roundWait>0||round<1)return;
  const aliveCT=bots.some(b=>!b.dead&&b.team==='CT')||(playerTeam==='CT'&&P.hp>0);
  const aliveT=bots.some(b=>!b.dead&&b.team==='T')||(playerTeam==='T'&&P.hp>0);
  if(!aliveCT||!aliveT){const winner=aliveCT?'CT':aliveT?'T':null;
   if(winner)Phase10.roundEnd(winner);roundWait=3;
  }
 }
 function openSettings(){if(!running||spectating)return;
  returningToGame=true;running=false;resetInputs();$('settingsScreen').classList.remove('hidden');if(document.pointerLockElement)document.exitPointerLock()}
 function closeSettings(){if(!returningToGame)return;returningToGame=false;
  if(!over){running=true;t0=performance.now();resetInputs()}}
 const bloodTexCache=new Map();function bloodTexture(id){if(!bloodTexCache.has(id)){const tex=new THREE.TextureLoader().load('assets/phase10/fx/'+id+'.png');bloodTexCache.set(id,tex)}return bloodTexCache.get(id)}
 function bloodHit(bot,hit,head=false){if(!S||!hit)return;
  const pos=hit.clone();const toward=pos.clone().sub(cam.position).normalize();
  const img=head?'blood_v1_bigblood1':'blood_v1_bigblood2';
  // Spray clusters follow bullet impact; bounded lifetime and bounded count.
  for(let n=0;n<(head?5:3);n++){
   const tex=bloodTexture(n%2?'blood_v1_blood1':'blood_v1_blood3');
   const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false,opacity:.92,color:0xffffff}));
   sprite.position.copy(pos).add(new THREE.Vector3((Math.random()-.5)*.4,(Math.random()-.5)*.5,(Math.random()-.5)*.4));
   const scale=.2+Math.random()*.28;sprite.scale.set(scale,scale,1);S.add(sprite);
   bloodBursts.push({obj:sprite,age:0,life:.28+Math.random()*.35});
  }
  const rayBlood=new THREE.Raycaster(pos.clone().addScaledVector(toward,.03),toward,.01,3.5);
  const surface=rayBlood.intersectObjects(obsM,false)[0];
  if(surface){const geo=new THREE.PlaneGeometry(head?1.2:.8,head?1.2:.8);
   const mat=new THREE.MeshBasicMaterial({map:bloodTexture(img),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,side:THREE.DoubleSide,opacity:.92});
   const decal=new THREE.Mesh(geo,mat);const normal=(surface.face?.normal||new THREE.Vector3(0,0,1)).clone().transformDirection(surface.object.matrixWorld);
   decal.position.copy(surface.point).addScaledVector(normal,.018);decal.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),normal);decal.rotateZ(Math.random()*6.28);S.add(decal);bloodDecals.push(decal);
   while(bloodDecals.length>20){const old=bloodDecals.shift();S.remove(old);old.geometry.dispose();old.material.dispose()}
  }
  while(bloodBursts.length>26){const o=bloodBursts.shift();S.remove(o.obj);o.obj.material.dispose()}
 }
 function updateBlood(dt){for(let i=bloodBursts.length-1;i>=0;i--){const b=bloodBursts[i];b.age+=dt;b.obj.material.opacity=Math.max(0,.92*(1-b.age/b.life));if(b.age>=b.life){S.remove(b.obj);b.obj.material.dispose();bloodBursts.splice(i,1)}}}
 function clearBlood(){for(const d of bloodDecals){S?.remove(d);d.material.dispose();d.geometry.dispose()}bloodDecals.length=0;
  for(const p of bloodBursts){S?.remove(p.obj);p.obj.material.dispose()}bloodBursts.length=0}
 function setup(){try{hand=localStorage.getItem('bs13-weapon-hand')==='left'?'left':'right'}catch(e){}$('weaponHand').value=hand;
  try{const settings=JSON.parse(localStorage.getItem('bs13-preferences')||'null');if(settings){
    if(['0','1','2'].includes(String(settings.q)))$('q').value=String(settings.q);
    if(Number.isFinite(Number(settings.sens))&&Number(settings.sens)>=.002&&Number(settings.sens)<=.009)$('sn').value=String(settings.sens);
    if(Number.isFinite(settings.volume)){$('volume').value=String(Math.max(0,Math.min(1,settings.volume)));masterVolume=+$('volume').value;}
  }}catch(e){}
  const persist=()=>{try{localStorage.setItem('bs13-preferences',JSON.stringify({q:$('q').value,sens:$('sn').value,volume:+$('volume').value}))}catch(e){}};
  for(const [id,event] of [['q','change'],['sn','change'],['volume','input']])$(id).addEventListener(event,persist);

  $('weaponHand').addEventListener('change',e=>setHand(e.target.value));
  $('flashBtn').addEventListener('click',e=>{e.stopPropagation();toggleFlashlight()});
  $('dropBtn').addEventListener('click',e=>{e.stopPropagation();Phase9.dropPlayerWeapon()});
  $('teamBtn').addEventListener('click',e=>{e.stopPropagation();openTeamMenu()});
  $('settingsGameBtn').addEventListener('click',e=>{e.stopPropagation();openSettings()});
  $('weaponBtn').addEventListener('click',e=>{e.stopPropagation();openWeaponSelector()});
  $('weaponClose').onclick=closeWeaponSelector;$('teamClose').onclick=closeTeamMenu;
  for(const b of document.querySelectorAll('[data-switch-team]'))b.addEventListener('click',()=>queueTeam(b.dataset.switchTeam));
  $('specNext').addEventListener('click',()=>pickBot(1,true));$('specPrev').addEventListener('click',()=>pickBot(-1,true));
  $('specMode').addEventListener('change',e=>setSpecMode(e.target.value));
  $('specAuto').addEventListener('click',()=>toggleDirector());
  // Drag the world to orbit, look freely or pan the overview, including on Safari touch.
  const pad=$('pad');
  pad.addEventListener('pointerdown',e=>{
   if(!spectating)return;
   e.preventDefault();e.stopImmediatePropagation();
   if(!['free','chase','map'].includes(specMode))return;
   if(specGesture)return;
   specGesture={id:e.pointerId,x:e.clientX,y:e.clientY};
   if(pad.setPointerCapture)pad.setPointerCapture(e.pointerId);
  },true);
  pad.addEventListener('pointermove',e=>{
   if(!spectating||!specGesture||e.pointerId!==specGesture.id)return;
   e.preventDefault();e.stopImmediatePropagation();
   const dx=Spectator15E.clamp(e.clientX-specGesture.x,-90,90),dy=Spectator15E.clamp(e.clientY-specGesture.y,-90,90);
   specGesture.x=e.clientX;specGesture.y=e.clientY;
   if(specMode==='chase'){orbitYaw-=dx*SENS;orbitPitch=Spectator15E.clamp(orbitPitch+dy*SENS,.08,1.3)}
   if(specMode==='free'){freeYaw-=dx*SENS;freePitch=Spectator15E.clamp(freePitch-dy*SENS,-1.42,1.42)}
   if(specMode==='map'){mapCenter.x-=dx*mapHeight*.012;mapCenter.z-=dy*mapHeight*.012}
  },true);
  const endSpecGesture=e=>{if(!spectating||!specGesture||specGesture.id!==e.pointerId)return;
   e.stopImmediatePropagation();specGesture=null};
  pad.addEventListener('pointerup',endSpecGesture,true);pad.addEventListener('pointercancel',endSpecGesture,true);
  pad.addEventListener('wheel',e=>{if(!spectating||specMode!=='map')return;
   e.preventDefault();e.stopPropagation();mapHeight=Spectator15E.clamp(mapHeight+(e.deltaY>0?4:-4),18,110)
  },{capture:true,passive:false});
  for(const b of document.querySelectorAll('[data-spec-move]')){
   const name=b.dataset.specMove;
   b.addEventListener('pointerdown',e=>{if(!spectating)return;e.preventDefault();e.stopPropagation();
    specKeys[name]=true;b.classList.add('active');if(b.setPointerCapture)b.setPointerCapture(e.pointerId)});
   for(const kind of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(kind,e=>{
    e.stopPropagation();specKeys[name]=false;b.classList.remove('active')});
  }

  for(const el of [$('weaponOverlay'),$('teamOverlay'),$('spectatorHud'),$('spectatorMove')])for(const event of ['pointerdown','pointermove','pointerup','wheel'])el.addEventListener(event,e=>e.stopPropagation());
  $('settingsScreen').querySelector('[data-close]').addEventListener('click',closeSettings);
  addEventListener('keydown',e=>{
   if(e.code==='KeyF'&&running&&!e.repeat)toggleFlashlight();
   if(e.code==='KeyQ'&&running&&!e.repeat)Phase9.dropPlayerWeapon();
   if(e.code==='KeyM'&&running&&!e.repeat)openTeamMenu();
   if(spectating){
    const movement={KeyW:'forward',ArrowUp:'forward',KeyS:'back',ArrowDown:'back',KeyA:'left',KeyD:'right',Space:'up',ShiftLeft:'down',ShiftRight:'down'};
    if(movement[e.code]){specKeys[movement[e.code]]=true;e.preventDefault()}
    if(!e.repeat){
     if(e.code==='ArrowRight')pickBot(1,true);
     if(e.code==='ArrowLeft')pickBot(-1,true);
     if(e.code==='KeyC')setSpecMode(Spectator15E.nextMode(specMode));
     if(e.code==='KeyP')toggleDirector();
     if(/^Digit[1-6]$/.test(e.code))setSpecMode(Spectator15E.modeIds[+e.code[5]-1]);
    }
    if(['ArrowRight','ArrowLeft','KeyC','KeyP'].includes(e.code)||/^Digit[1-6]$/.test(e.code))e.preventDefault();
   }
   if(e.code==='Escape'){closeWeaponSelector();closeTeamMenu()}
  });
  addEventListener('keyup',e=>{
   if(!spectating)return;
   const movement={KeyW:'forward',ArrowUp:'forward',KeyS:'back',ArrowDown:'back',KeyA:'left',KeyD:'right',Space:'up',ShiftLeft:'down',ShiftRight:'down'};
   if(movement[e.code])specKeys[movement[e.code]]=false;
  });
  addEventListener('blur',resetSpecMovement);
 }
 setup();
 return {moveSpeed,isSpectating,visibleOverlay,applyHand,setHand,bindLight,toggleFlashlight,
  resetMatch,beforeRound,onDeath,getObserved:()=>observed,updateSpectator,shouldRenderSpecWeapon,setSpecMode,toggleDirector,pickBot,checkRoundEnd,openSettings,closeSettings,
  openWeaponSelector,closeWeaponSelector,openTeamMenu,queueTeam,dropPlayerWeapon:()=>Phase9.dropPlayerWeapon(),bloodHit,updateBlood,clearBlood,
  getDebugState:()=>({spectating,observed:observed?.botId||null,specMode,autoDirector,queuedTeam,lightEnabled,hand,bloodDecals:bloodDecals.length,bloodBursts:bloodBursts.length})};
})();
