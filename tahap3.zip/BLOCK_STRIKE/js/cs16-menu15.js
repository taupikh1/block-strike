/* Classic single-player UI integration. Uses source-supplied GameMenu.res and
 * ClientScheme/GUI assets as structure, but all controls are native browser UI.
 * No GoldSrc DLL, cheats, online servers, or new maps are loaded.
 */
(function(){
 'use strict';
 const id=n=>document.getElementById(n);
 const KEY='bs-classic-menu15-v1';
 const RULE_KEY='bs-classic-match15-v1';
 const number=(value,def,min,max)=>{const n=Number(value);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):def;};
 const tryRead=(key)=>{try{return JSON.parse(localStorage.getItem(key)||'null')}catch(_){return null}};
 const trySave=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value))}catch(_){}};
 const defaults={playerName:'PLAYER',crosshairSize:22,crosshairColor:'green',hudScale:100};
 const allowedCross={green:'#7fff7f',yellow:'#ffe06d',cyan:'#79f8ff',white:'#ffffff'};
 const baseRules={roundSeconds:120,buyTime:15,startMoney:800};
 const permittedRounds=[60,90,120,180,300],permittedBuy=[10,15,30,45,60],permittedMoney=[800,1500,3000,5000,8000,16000];
 let prefs={...defaults,...(tryRead(KEY)||{})};
 let rules={...baseRules,...(tryRead(RULE_KEY)||{})};
 const fromAllowed=(value,allowed,fallback)=>allowed.includes(Number(value))?Number(value):fallback;
 rules.roundSeconds=fromAllowed(rules.roundSeconds,permittedRounds,120);
 rules.buyTime=fromAllowed(rules.buyTime,permittedBuy,15);
 rules.startMoney=fromAllowed(rules.startMoney,permittedMoney,800);
 const name=()=>String(prefs.playerName||'PLAYER').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,24)||'PLAYER';
 const showTabs=(rootName,attribute,panelAttribute,name)=>{
  const root=id(rootName);if(!root)return;
  const buttons=[...root.querySelectorAll('button['+attribute+']')];
  const activate=tab=>{
   buttons.forEach(button=>{
    const selected=button.getAttribute(attribute)===tab;
    button.classList.toggle('active',selected);
    button.setAttribute('aria-selected',String(selected));
    button.tabIndex=selected?0:-1;
   });
   document.querySelectorAll('['+panelAttribute+']').forEach(panel=>panel.classList.toggle('hidden',panel.getAttribute(panelAttribute)!==tab));
  };
  buttons.forEach(button=>button.addEventListener('click',()=>activate(button.getAttribute(attribute))));
  root.addEventListener('keydown',event=>{
   if(event.key!=='ArrowRight'&&event.key!=='ArrowLeft')return;
   const i=buttons.indexOf(document.activeElement);if(i<0)return;
   event.preventDefault();const next=buttons[(i+(event.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length];
   activate(next.getAttribute(attribute));next.focus();
  });
  return activate;
 };
 const activateOptions=showTabs('optionsTabs','data-options-tab','data-options-panel','options');
 const activateCreate=showTabs('createTabs','data-create-tab','data-create-panel','create');
 function applyAppearance(){
  const color=Object.hasOwn(allowedCross,prefs.crosshairColor)?prefs.crosshairColor:'green';
  const size=number(prefs.crosshairSize,22,12,38);
  const hud=number(prefs.hudScale,100,80,125);
  document.documentElement.style.setProperty('--cs-cross-color',allowedCross[color]);
  document.documentElement.style.setProperty('--cross-size',size+'px');
  document.documentElement.style.setProperty('--cs-hud-scale',hud/100);
  // Only scale visible status, not click targets, to keep touch hit-boxes stable.
  const status=['hp','armor','economy','ammo','gear'];
  status.forEach(k=>{const e=id(k);if(e)e.style.zoom=String(hud/100)});
 }
 function syncPrefs(){
  const nameEl=id('playerNickname');if(nameEl)nameEl.value=name();
  id('crosshairColor').value=Object.hasOwn(allowedCross,prefs.crosshairColor)?prefs.crosshairColor:'green';
  id('crosshairSize').value=String(number(prefs.crosshairSize,22,12,38));
  id('hudScale').value=String(number(prefs.hudScale,100,80,125));
  id('crossSizeValue').value=id('crosshairSize').value;
  id('hudScaleValue').value=id('hudScale').value+'%';
  id('sensitivityValue').value=(Number(id('sn').value)*1000).toFixed(1);
  id('volumeValue').value=Math.round(Number(id('volume').value)*100)+'%';
  applyAppearance();
 }
 function persistPrefs(){prefs.playerName=name();trySave(KEY,prefs);applyAppearance()}
 id('playerNickname').addEventListener('input',event=>{prefs.playerName=event.target.value;persistPrefs()});
 id('crosshairSize').addEventListener('input',event=>{prefs.crosshairSize=number(event.target.value,22,12,38);id('crossSizeValue').value=String(prefs.crosshairSize);persistPrefs()});
 id('crosshairColor').addEventListener('change',event=>{prefs.crosshairColor=event.target.value;persistPrefs()});
 id('hudScale').addEventListener('input',event=>{prefs.hudScale=number(event.target.value,100,80,125);id('hudScaleValue').value=prefs.hudScale+'%';persistPrefs()});
 id('sn').addEventListener('input',event=>{id('sensitivityValue').value=(Number(event.target.value)*1000).toFixed(1);event.target.dispatchEvent(new Event('change',{bubbles:false}))});
 id('volume').addEventListener('input',event=>{id('volumeValue').value=Math.round(Number(event.target.value)*100)+'%'});
 id('optionsDefaults').addEventListener('click',()=>{
  prefs={...defaults};persistPrefs();
  for(const [field,value] of [['q','1'],['sn','0.0045'],['volume','0.8'],['weaponHand','right'],['crouchMode','toggle'],['classicModels','on']]){
   const e=id(field);e.value=value;e.dispatchEvent(new Event(field==='volume'?'input':'change',{bubbles:true}));
  }
  syncPrefs();id('optionsStatus').textContent='Defaults restored';
 });
 // Settings use a reversible editing session: Cancel/X restores controls and saved values.
 let optionsSnapshot=null;
 const nativeOptions=['q','sn','volume','weaponHand','crouchMode','classicModels'];
 const captureOptions=()=>{
  optionsSnapshot={prefs:{...prefs},fields:Object.fromEntries(nativeOptions.map(key=>[key,id(key).value]))};
 };
 const restoreOptions=()=>{
  if(!optionsSnapshot)return;
  const snap=optionsSnapshot;optionsSnapshot=null;
  prefs={...snap.prefs};trySave(KEY,prefs);
  for(const [field,value] of Object.entries(snap.fields)){
   const el=id(field);if(!el||el.value===value)continue;
   el.value=value;el.dispatchEvent(new Event(field==='volume'?'input':'change',{bubbles:true}));
  }
  syncPrefs();
 };
 const closeOptions=()=>{const cancel=id('settingsScreen').querySelector('[data-close]');if(cancel)cancel.click()};
 id('settingsScreen').querySelector('[data-close]').addEventListener('click',restoreOptions,true);
 id('optionsApply').addEventListener('click',()=>{optionsSnapshot=null;persistPrefs();closeOptions()});
 id('optionsCloseX').addEventListener('click',closeOptions);
 const originalSettings=id('settingsBtn').onclick;
 id('settingsBtn').onclick=()=>{
  captureOptions();
  if(typeof originalSettings==='function')originalSettings();else id('settingsScreen').classList.remove('hidden');
  activateOptions('multiplayer');syncPrefs();
 };
 // In-match settings are opened by Phase13 directly, not through settingsBtn.
 id('settingsGameBtn').addEventListener('click',()=>{
  captureOptions();queueMicrotask(()=>{if(!id('settingsScreen').classList.contains('hidden')){activateOptions('multiplayer');syncPrefs()}});
 },true);
 const openStatus=msg=>{id('offlineNotice').textContent=msg};
 id('findServersBtn').addEventListener('click',()=>openStatus('Find Servers requires network multiplayer. BLOCK STRIKE currently supports offline bot matches only.'));
 id('quitBtn').addEventListener('click',()=>id('quitDialog').classList.remove('hidden'));
 const hideQuit=()=>id('quitDialog').classList.add('hidden');
 id('quitClose').onclick=id('quitBack').onclick=hideQuit;
 id('quitExitMatch').onclick=()=>{
  hideQuit();if(typeof pauseToMenu==='function')pauseToMenu();
  over=true;id('resumeBtn').classList.add('hidden');openStatus('Match closed. Choose New Game to start a fresh local game.');
 };
 function syncRules(){
  id('matchRoundTime').value=String(rules.roundSeconds);
  id('matchBuyTime').value=String(rules.buyTime);
  id('matchStartMoney').value=String(rules.startMoney);
 }
 function saveRules(){
  rules={roundSeconds:fromAllowed(id('matchRoundTime').value,permittedRounds,120),
   buyTime:fromAllowed(id('matchBuyTime').value,permittedBuy,15),
   startMoney:fromAllowed(id('matchStartMoney').value,permittedMoney,800)};
  trySave(RULE_KEY,rules);
 }
 for(const control of ['matchRoundTime','matchBuyTime','matchStartMoney'])id(control).addEventListener('change',saveRules);
 // Phase10 is the owner of actual bot count/difficulty. Keep both UI fields in sync.
 const total=id('matchPlayers'),botInput=id('matchBotCount'),botDiff=id('matchDifficulty');
 const syncBotCount=()=>{botInput.value=String(Math.max(1,Number(Phase10.config.players)-1))};
 total.addEventListener('input',syncBotCount);
 total.addEventListener('change',syncBotCount);
 botInput.addEventListener('input',()=>{if(botInput.value==='')return;Phase10.setConfig({players:number(botInput.value,15,1,31)+1});syncBotCount()});
 botInput.addEventListener('change',()=>{Phase10.setConfig({players:number(botInput.value,15,1,31)+1});syncBotCount()});
 botDiff.addEventListener('change',()=>Phase10.preview());
 let createSnapshot=null;
 const openCreate=()=>{
  if(typeof Phase10==='undefined')return;
  createSnapshot={config:{...Phase10.config},rules:{...rules}};
  id('menu').classList.add('hidden');id('matchConfigScreen').classList.remove('hidden');
  activateCreate('server');
  selectedMapId='dust_block';id('createMap').value='dust_block';
  syncRules();Phase10.preview();syncBotCount();
 };
 id('go').onclick=openCreate;
 id('selectMapBtn').onclick=openCreate;
 id('createClose').onclick=()=>id('backMatchConfig').click();
 id('backMatchConfig').addEventListener('click',()=>{
  if(!createSnapshot)return;
  Phase10.setConfig(createSnapshot.config);
  rules=createSnapshot.rules;trySave(RULE_KEY,rules);syncRules();syncBotCount();
  createSnapshot=null;
 });
 id('continueMatchConfig').addEventListener('click',()=>{
  saveRules();selectedMapId='dust_block';createSnapshot=null;
 });
 // Prevent accidental keyboard shots when changing settings during gameplay.
 document.addEventListener('keydown',event=>{
  if(event.key!=='Escape')return;
  if(!id('quitDialog').classList.contains('hidden')){event.stopImmediatePropagation();event.preventDefault();hideQuit();return}
  if(!id('settingsScreen').classList.contains('hidden')){event.stopImmediatePropagation();event.preventDefault();closeOptions();return}
  if(!id('matchConfigScreen').classList.contains('hidden')){event.stopImmediatePropagation();event.preventDefault();id('backMatchConfig').click()}
 },true);
 syncPrefs();syncRules();syncBotCount();
 window.PhaseMenu15={get rules(){return {...rules}},get playerName(){return name()},openCreate,saveRules,openOptions:()=>id('settingsBtn').click()};
})();
